@echo off
rem SoftInza OSINT setup (Windows). Double-click or run: setup.bat
cd /d "%~dp0"
echo == SoftInza OSINT setup ==
where node >nul 2>nul || (echo Node.js 20+ is required: https://nodejs.org & pause & exit /b 1)
for /f %%v in ('node -p "process.versions.node.split('.')[0]"') do set NV=%%v
if %NV% LSS 20 (echo Node 20+ required, found %NV% & pause & exit /b 1)
call npm install || (echo npm install failed & pause & exit /b 1)
if not exist .env (copy .env.example .env >nul & echo Created .env)
call npm test
echo.
echo Verify with real data: npm run selfcheck yourdomain.com
echo Setup finished. Starting at http://localhost:5100 ...
call npm start
