#!/usr/bin/env node
// Usage: node scripts/selfcheck.js [domain] [--offline]
// Phase 1 (skipped with --offline): is every live data source reachable from THIS machine?
// Phase 2: starts the real server and runs a scan, stream, Word/PDF export, cache and quota checks.
require("../lib/env");
const { spawn } = require("child_process"), path = require("path"), os = require("os");
const args = process.argv.slice(2), offline = args.includes("--offline"), domain = args.find((a) => !a.startsWith("--")) || "example.com";
const rows = [], rec = (name, ok, detail = "") => rows.push([name, ok ? "PASS" : "FAIL", detail]);

async function sources() {
  const axios = require("axios"), d = domain;
  const T = [["RDAP", `https://rdap.org/domain/${d}`], ["crt.sh", `https://crt.sh/?q=%25.${d}&output=json`], ["AlienVault OTX", `https://otx.alienvault.com/api/v1/indicators/domain/${d}/passive_dns`],
    ["Anubis", `https://jldc.me/anubis/subdomains/${d}`], ["RIPEstat", "https://stat.ripe.net/data/prefix-overview/data.json?resource=1.1.1.1"], ["Shodan InternetDB", "https://internetdb.shodan.io/1.1.1.1"],
    ["CISA KEV", "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"], ["Wayback CDX", `https://web.archive.org/cdx/search/cdx?url=${d}&output=json&limit=1`],
    ["OpenPhish", "https://openphish.com/feed.txt"], ["GitHub API", "https://api.github.com/rate_limit"]];
  await Promise.all(T.map(async ([n, u]) => {
    const t = Date.now();
    try { const r = await axios.get(u, { timeout: 25000, validateStatus: () => true, headers: { "User-Agent": "OSINTAggregator-selfcheck" }, responseType: "text", maxContentLength: 80e6 });
      rec("Source: " + n, r.status < 500 && ![403, 429].includes(r.status), `HTTP ${r.status}, ${Date.now() - t} ms${r.status === 404 ? " (404 can be normal when there is no data)" : ""}`);
    } catch (e) { rec("Source: " + n, false, e.code || e.message); }
  }));
}

async function smoke() {
  const port = 20000 + Math.floor(Math.random() * 20000), base = `http://127.0.0.1:${port}`;
  const env = { ...process.env, PORT: String(port), HOST: "127.0.0.1", RATE_LIMIT: "50", DATA_DIR: path.join(os.tmpdir(), "softinza-selfcheck-" + Date.now()), COLLECTOR_TIMEOUT_MS: offline ? "3000" : process.env.COLLECTOR_TIMEOUT_MS || "60000" };
  const srv = spawn(process.execPath, [path.join(__dirname, "..", "server.js")], { env, stdio: "ignore" });
  let cookie = "";
  const j = (u, o = {}) => fetch(base + u, { redirect: "manual", ...o, headers: { ...(o.headers || {}), ...(cookie ? { Cookie: cookie } : {}) } });
  const post = (u, b, h = {}) => j(u, { method: "POST", headers: { "Content-Type": "application/json", ...h }, body: JSON.stringify(b) });
  const grab = (r) => { const c = r.headers.getSetCookie ? r.headers.getSetCookie()[0] : r.headers.get("set-cookie"); if (c) cookie = c.split(";")[0]; return c || ""; };
  const email = `selfcheck-${Date.now()}@example.com`, pw = "selfcheck-pass-9";
  try {
    for (let i = 0; i < 40; i++) { try { if ((await j("/api/health")).ok) break; } catch {} await new Promise((r) => setTimeout(r, 300)); }
    rec("Server starts, /api/health", (await j("/api/health")).ok);
    rec("Guest homepage is available", (await j("/")).status === 200);
    rec("Guest scan API still requires consent", (await post("/api/recon/stream", { domain })).status === 400);
    rec("Weak password is rejected", (await post("/api/auth/register", { email, password: "short" })).status === 400);
    rec("Cross-site request is blocked", (await post("/api/auth/login", { email, password: pw }, { Origin: "http://evil.example" })).status === 403);
    const reg = await post("/api/auth/register", { email, password: pw, name: "Self Check" }); const sc = grab(reg);
    rec("Account can be created", reg.ok && !!cookie);
    rec("Session cookie is HttpOnly and SameSite", /HttpOnly/i.test(sc) && /SameSite=Lax/i.test(sc));
    rec("Dashboard opens when signed in", (await j("/")).status === 200);
    rec("/api/auth/me returns the user", ((await (await j("/api/auth/me")).json()).user || {}).email === email);
    rec("Consent is required to scan", (await post("/api/recon/stream", { domain })).status === 400);
    rec("Internal targets are refused", (await (await post("/api/recon/stream", { domain: "localhost", consent: true })).text()).includes("valid public domain"));
    const lines = (await (await post("/api/recon/stream", { domain, consent: true })).text()).trim().split("\n").map((l) => JSON.parse(l));
    const prog = lines.filter((l) => l.progress), done = (lines.find((l) => l.done) || {}).done;
    rec("Live progress lines are streamed", prog.length >= 5, `${prog.length} collectors reported`);
    rec("Final report has all parts", !!(done && done.risk && done.graph && done.evidence && done.googleDorks && done.timeline && done.risk.findings.every((x) => x.source && x.confidence)));
    if (done) {
      const failed = prog.filter((l) => !l.ok).map((l) => l.progress);
      rec("Collectors succeeded", offline || failed.length < prog.length / 2, failed.length ? `failed: ${failed.join(", ")}` : "all ok");
      const list = (await (await j("/api/reports")).json()).reports || [];
      rec("Report was saved to My Reports", list.length === 1 && list[0].domain === done.domain);
      rec("Saved report can be reopened", list[0] && ((await (await j("/api/reports/" + list[0].id)).json()).domain === done.domain));
      for (const f of ["docx", "pdf"]) { const r = await post("/api/export/" + f, { report: done }), b = Buffer.from(await r.arrayBuffer()); rec(`${f.toUpperCase()} export`, r.ok && b.subarray(0, 4).toString().startsWith(f === "pdf" ? "%PDF" : "PK"), `${b.length} bytes`); }
      rec("Repeat scan served from cache with expiry", (await (await post("/api/recon/stream", { domain, consent: true })).text()).includes('"expiresAt"'));
      const lim = await (await j("/api/limit")).json(); rec("Quota used exactly once", lim.remaining === 49, `${lim.remaining}/${lim.limit} left`);
    }
    rec("Guest IP lookup requires consent and refuses private targets", (await fetch(base + "/api/ipscan", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).status === 400 && (await post("/api/ipscan", { ip: "1.1.1.1" })).status === 400 && (await post("/api/ipscan", { ip: "10.0.0.1", consent: true })).status === 400);
    const ipr = await post("/api/ipscan", { ip: "1.1.1.1", consent: true }), ipd = await ipr.json().catch(() => ({}));
    rec("IP lookup returns a structured report", ipr.ok && ipd.ip === "1.1.1.1" && !!ipd.risk && Array.isArray(ipd.evidence));
    rec("Company finder validates input", (await post("/api/company-lookup", { name: "a" })).status === 400);
    rec("Wrong password is rejected", (await post("/api/account/password", { current: "wrong-pass-1", next: "another-pass-2" })).status === 401);
    await post("/api/auth/logout", {}); const old = cookie; cookie = old;
    rec("Logout ends the session", (await j("/api/auth/me")).status === 401);
    const li = await post("/api/auth/login", { email, password: pw }); grab(li); rec("Log in again works", li.ok);
    rec("Account can be deleted", (await post("/api/account/delete", { password: pw })).ok);
    cookie = ""; rec("Deleted account cannot log in", (await post("/api/auth/login", { email, password: pw })).status === 401);
  } catch (e) { rec("Smoke test", false, e.message); } finally { srv.kill(); }
}

(async () => {
  console.log(`SoftInza selfcheck: domain=${domain}${offline ? " (offline: live sources skipped)" : ""}\n`);
  if (!offline) await sources();
  await smoke();
  const w = Math.max(...rows.map((r) => r[0].length));
  rows.forEach(([n, s, d]) => console.log(`${s === "PASS" ? "PASS" : "FAIL"}  ${n.padEnd(w)}  ${d}`));
  const bad = rows.filter((r) => r[1] === "FAIL").length;
  console.log(`\n${rows.length - bad}/${rows.length} checks passed.${bad ? " For FAILs: check internet/firewall, retry later (public APIs rate-limit), then send me this output." : ""}`);
  process.exit(bad ? 1 : 0);
})();
