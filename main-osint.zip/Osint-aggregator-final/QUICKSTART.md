# SoftInza OSINT: quick start

## 1. Install and run (Node.js 20 or newer)
```
unzip Osint-aggregator-updated.zip && cd Osint-aggregator-main
npm install            # required: the zip contains no node_modules
cp .env.example .env   # then edit .env (everything is optional)
npm start              # http://127.0.0.1:5100
```
`setup.sh` / `setup.bat` do the same steps. Create an account on the login page, or use `/scan` as a guest. Signed-in users can tick "Run in the background" when starting a scan and close the tab; the result appears under My Reports and on the Dashboard.
Docker (the Dockerfile was read but NOT built or run in the environment this was prepared in):
```
docker build -t softinza .
docker run -p 5100:5100 -v softinza-data:/app/data --env-file .env softinza
```
The volume keeps accounts and reports; `--env-file` passes your settings (the container binds to 0.0.0.0, so put it behind HTTPS and set TRUST_PROXY=1, COOKIE_SECURE=1). Do not bake a real `.env` into an image you share.

## 2. Check it works on YOUR machine (nothing in this project was tested against the real internet)
```
npm test                                   # 68 automated tests (offline mock, no internet needed)
npm run selfcheck -- yourdomain.com        # live check of the real sources
```
Then scan a domain you own and open My Reports. In the report, "Coverage & Limitations" shows which sources answered.

## 3. Settings you will probably want (see .env.example)
- BRAND_NAME, BRAND_LOGO (web path) and BRAND_LOGO_FILE (PNG/JPG for PDF and DOCX), CTA_URL, CONTACT_EMAIL, TERMS_URL, PRIVACY_URL
- ALLOW_GUEST=0 to require sign-in; GUEST_RATE_LIMIT; TRUST_PROXY=1 behind a reverse proxy; COOKIE_SECURE=1 on HTTPS
- EXTERNAL_TOOLS (only if you installed Subfinder, Amass, theHarvester, SpiderFoot or Recon-ng yourself)

## 4. Read before going live
`DEPLOY.md` (persistent storage, proxy, limits), `TEST-REPORT.md` (what was and was NOT tested), `AUDIT.md` and `PHASE1-AUDIT.md` (status per requirement), `CHANGES.md` (everything that changed).
Not production-ready until you have verified the live sources and the report flow on your own server.
