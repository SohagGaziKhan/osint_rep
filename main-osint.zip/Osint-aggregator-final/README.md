# 🔍 OSINT Aggregator

A **passive-only** OSINT (Open-Source Intelligence) aggregation tool. Give it a domain, and it pulls together WHOIS, DNS, Certificate Transparency subdomains, publicly published social links/emails from the target's own website, robots.txt/sitemap.xml, and ready-to-use Google Dork queries — all into a single report.

Built by **Sohag Gazi Khan (SGK)**.

---

## ⚖️ Legal & Ethical Notice

> **This tool performs passive reconnaissance only.** It does not port-scan, brute-force, exploit, or send any intrusive traffic. Every data point it collects is either:
> - Public WHOIS registration data
> - Public DNS records
> - Public Certificate Transparency logs (crt.sh)
> - Content the target **already publishes on their own public website** (robots.txt, sitemap.xml, homepage HTML, social media links, public contact emails)
> - Google Dork **query links** — the tool never scrapes Google itself; it just builds the search URL for you to open manually
>
> This tool does **not** perform person-level lookups (no phone number search, no individual profiling, no scraping of personal social media data). It only aggregates **domain/organization-level** public information.
>
> Only run this against:
> - Domains **you own**
> - Targets with **explicit written authorization** (bug bounty scope, signed pentest engagement)
> - Publicly authorized practice targets
>
> Using this against systems you don't have permission to assess may be illegal in your jurisdiction. Use responsibly.

---

## ✨ What It Collects

| Category | Source | Data |
|---|---|---|
| **WHOIS / RDAP** | Public WHOIS servers and RDAP | Registrar and IANA ID, registry domain ID, registrar WHOIS endpoint, registration/update/expiry dates, nameservers, domain status, DNSSEC |
| **DNS** | Public DNS resolution | A, AAAA, MX, NS, TXT, SOA, CNAME records |
| **Subdomains** | Certificate Transparency and passive public sources | Discovered hostnames, source coverage, IPv4/IPv6/CNAME answers; DNS lookups are limited to the first 150 names |
| **Website Intel** | Target's own homepage HTML | Page title, meta description, social media links, public contact emails, tech-stack hints (headers + HTML signatures) |
| **robots.txt / sitemap.xml** | Target's own website | Disallowed paths, published site URLs |
| **Google Dorks** | Generated locally | 14 ready-to-click Google search queries (site:, filetype:, inurl: etc.) for further manual investigation |

---

## 🌟 Core Platform Features

SoftInza OSINT Aggregator is designed as a passive-only intelligence platform, combining domain, network, historical, and organizational investigation workflows into a single professional investigation toolkit.

### 1. 🔍 Domain Intelligence
- Domain registration details and registrar metadata
- Registry and registrar identifiers, WHOIS server, dates, status, nameservers and DNSSEC
- Technical registration fields only; personal registrant names, addresses, email addresses and phone numbers are not included
- Nameserver and domain lifecycle dates
- Public status and exposure signals
- Ownership and structure insight for investigative use

### 2. 🌐 Subdomain Discovery
- Certificate Transparency and public DNS discovery
- Subdomain collection across legitimate passive sources
- Per-host discovery source and passive A, AAAA and CNAME answers, with source availability and lookup limits shown
- Duplicate removal and source attribution
- Verification-aware results without implying live compromise

### 3. 📡 DNS Intelligence
- A, AAAA, MX, NS, TXT, CNAME, SOA and related records
- SPF and DMARC observations
- DNS configuration visibility for operational context
- Public DNS evidence tied to the source and collection time

### 4. 🖥️ IP Intelligence
- ASN, organization/provider context, and network metadata
- Reverse DNS and approximate geolocation estimates
- Public reputation and related threat references
- Safe handling for private and internal IP ranges

### 5. 🕰️ Historical Intelligence
- Internet Archive snapshots and historical references
- Previously indexed URLs and domain history
- Temporal correlations across public records
- Timeline-oriented evidence for investigations

### 6. 🚨 Threat Intelligence & Risk Analysis
- Public threat and reputation signals from legitimate sources
- Relevant vulnerability and abuse references
- Confidence-aware risk interpretation
- Clear separation between unverified indicators and confirmed findings

### 7. 🐙 GitHub Intelligence
- Public repository and organization relationships
- Domain-related GitHub mentions and metadata
- Public project footprint analysis
- Redaction-safe handling of sensitive or potentially exposed data

### 8. 🏢 Company Intelligence
- Public organizational and business profile references
- Website and domain associations
- Public social and business metadata
- Source-based confidence and reliability tagging

### 9. 🕸️ Relationship Graph
- Domain-to-IP, domain-to-subdomain, and organization links
- Cross-entity intelligence mapping
- Source-backed relationship evidence
- Visual structure for operational understanding

### 10. ⚡ Live Scan Progress
- Real-time scan status by module
- Source-level success/failure tracking
- Partial results and failure transparency
- Investigative workflow visibility during collection

### 11. ✅ Evidence & Verification System
- Source attribution for every major finding
- Evidence and collection timestamp tracking
- Verification states such as verified, unverified, failed, and partial
- Stronger professionalism than conventional scraping-only tools

### 12. 📊 Risk & Confidence Engine
- Risk evaluation separated from confidence estimation
- Data reliability clearly distinguished from impact assessment
- Better decision support for analysts and investigators

### 13. 📄 Professional Investigation Report
- Executive summary and target overview
- Evidence-backed findings and source references
- Risk assessment and historical context
- Export options for PDF, DOCX, JSON, and HTML

### 14. 👤 User Accounts & My Reports
- Registration and login flows
- Secure session handling
- Saved investigations and historical reports
- Per-user report isolation and account management

## 🛠️ Tech Stack

- **Node.js + Express** — backend & REST API
- **Cheerio** — HTML/XML parsing
- **Axios** — HTTP requests
- **Node's built-in `dns` module** — DNS resolution
- **whois** (npm) — raw WHOIS protocol client

---

## 🚀 Getting Started

### Prerequisites
- Node.js v18+

### Installation

```bash
git clone https://github.com/SohagGaziKhan/osint-aggregator.git
cd osint-aggregator
npm install
```

### Run

```bash
npm start
```

Open **http://localhost:5100** and enter a domain you're authorized to assess.

---

## 📡 API

**Endpoint:** `POST /api/recon`

**Request:**
```json
{ "domain": "example.com" }
```

**Response (abridged):**
```json
{
  "domain": "example.com",
  "whois": { "registrar": "...", "creationDate": "...", "expiryDate": "..." },
  "dns": { "A": ["..."], "MX": ["..."] },
  "subdomains": ["www.example.com", "mail.example.com"],
  "website": {
    "title": "...",
    "socialLinks": { "LinkedIn": "linkedin.com/company/..." },
    "emails": ["contact@example.com"],
    "techStack": ["WordPress", "Cloudflare"]
  },
  "robotsTxt": { "found": true, "lines": ["..."] },
  "sitemap": { "found": true, "urls": ["..."] },
  "googleDorks": [{ "label": "PDF documents", "query": "site:example.com filetype:pdf", "url": "https://..." }]
}
```

---

## 📌 Roadmap

- [ ] ASN / IP range lookup
- [ ] Export report as PDF
- [ ] Historical WHOIS/DNS diff tracking
- [ ] Wayback Machine snapshot listing

---

## 👤 Author

**Sohag Gazi Khan (SGK)**
Founder @SoftInza | MERN Stack Developer | Ethical Hacker | SEO Specialist | Video Editor

- GitHub: [@SohagGaziKhan](https://github.com/SohagGaziKhan)

---

## 📄 License

MIT License. For educational and authorized security research use only.


---

## 🆕 v2.0 (all free, no API keys)

- **RDAP** (rdap.org) alongside WHOIS, **IP/ASN/prefix** (RIPEstat), **open ports / CVEs** (Shodan InternetDB)
- **Wayback Machine** snapshot history (first/latest/monthly)
- **Security headers**, **SSL certificate** details, **SPF/DMARC** check
- **Report export**: HTML, JSON, and Print/Save-as-PDF
- Fixes: domain validation + private-IP (SSRF) guard, server binds to `127.0.0.1` by default (`HOST=0.0.0.0` to expose), parallel DNS, XSS-safe UI, email false-positive filter, per-module error isolation

Note: SSL/header checks connect to the target on 443 like a normal browser visit; Shodan InternetDB is free for non-commercial use. Still only use on authorized targets.

## 🆕 v2.1

Subdomains from crt.sh + AlienVault OTX + Anubis with live/dead and takeover (dangling CNAME) checks · CVEs cross-checked against CISA KEV · risk summary · scan history & diff (`data/`) · DKIM/MTA-STS/CAA/security.txt/cookie flags · lookalike-domain finder · Wayback historical URLs · CLI (`node cli.js example.com`) · Dockerfile (`docker run -p 127.0.0.1:5100:5100 ...`).

## 🆕 v2.2

Company & brand profile (JSON-LD, Open Graph, published emails/phones, About/Contact/Team/Careers pages) · social discovery with 3 classes: *Officially linked* / *Strong match* / *Unverified* · website inventory (feeds, manifest, canonical, favicon, schema types, public PDFs). Only company-published info is collected; no personal data from Team pages.

## 🆕 v2.3 — SoftInza report

Threat feeds (OpenPhish; URLhaus if `URLHAUS_KEY` is set) · hosting/CDN & mail-provider detection · image/media inventory + reverse-image-search links · GitHub footprint · timeline · entity relationship graph · evidence table (source, status, confidence) · **Word and PDF report** (`npm install` pulls `docx` and `pdf-lib`).
CLI: `node cli.js example.com --docx report.docx --pdf report.pdf --json report.json`. PDF uses standard fonts (Latin-1); the Word file keeps all scripts.

## 🆕 v2.4

Redesigned UI (dark/light, summary cards, section nav, consent checkbox) · **Google Dorks** now a top section with 8 categories, Google/Copy buttons, and review/rating links · **Rate limit** per IP (`RATE_LIMIT=3`, `RATE_WINDOW_MIN=60`), same-domain 24h cache does not use quota, failed scans refund quota · recent reports kept in the browser · set `TRUST_PROXY=1` behind a reverse proxy.

## 🆕 v2.6

**Quick start:** run `setup.bat` (Windows) or `./setup.sh` (Linux/macOS): checks Node 20+, installs, creates `.env`, runs tests. Settings live in `.env` (see `.env.example`). Full feature guide: `docs/SoftInza-OSINT-Complete-Guide.pdf`.

## 🆕 v2.7

Persistent quota and cache (`data/`, IPs stored only as salted hashes, `CACHE_TTL_HOURS`) · findings carry source, time, confidence, verified flag and fix; unverified findings cannot make the overall level High · 14 module tiles with Loading/OK/Warning/Unavailable status · searchable Google Dorks · Recommended Actions in Word/PDF · `npm run selfcheck [domain] [--offline]` checks every live source and runs a full server test.

## 🆕 v3.0 — accounts

Login/registration (email + password, scrypt, HttpOnly sessions, SQLite), login required to run reports, quota per account, **My Reports** (last 30, saved automatically), **Account** page (name, password change, delete account), sidebar layout with optional SoftInza link and CTA from `.env`. `npm run selfcheck` now also tests sign-up, login, sessions, saved reports and account deletion.

## 🆕 v3.1

**IP lookup** (ASN, prefix, approximate location, reverse DNS, Shodan ports/CVEs, CISA KEV, Feodo botnet-C2 list) and **company finder** (company name -> official website via Wikidata) next to the domain report.
