const test = require("node:test"), assert = require("node:assert"), B = require("../lib/breaker");
test("opens after N reachability failures, allows one trial after the cooldown, closes on success", () => {
  process.env.BREAKER_FAILURES = "3"; process.env.BREAKER_COOLDOWN_SEC = "60"; B.reset(); const t0 = 1_000_000;
  assert.ok(B.allow("RDAP", t0)); B.failure("RDAP", t0); B.failure("RDAP", t0); assert.ok(B.allow("RDAP", t0), "still closed after 2 of 3");
  B.failure("RDAP", t0); assert.equal(B.allow("RDAP", t0 + 1000), false); assert.equal(B.retryIn("RDAP", t0 + 1000), 59);
  assert.ok(B.allow("RDAP", t0 + 61000), "half-open: one trial once the cooldown has passed");
  B.failure("RDAP", t0 + 61000); assert.equal(B.allow("RDAP", t0 + 62000), false, "a failed trial re-opens it at once");
  B.success("RDAP"); assert.ok(B.allow("RDAP", t0 + 62000)); assert.equal(B.failures("RDAP"), 0);
});
test("only reachability errors count, and target-facing collectors are never guarded", () => {
  for (const e of ["connect ECONNREFUSED 1.2.3.4:443", "timed out", "Request failed with status code 429", "Request failed with status code 503", "source unavailable: x"]) assert.ok(B.countable(e), e);
  for (const e of ["Request failed with status code 404", "Unexpected token < in JSON at position 0", "no RDAP server for this TLD"]) assert.equal(B.countable(e), false, e);
  for (const n of ["Website", "SSL", "SPF/DMARC", "security.txt", "Lookalikes", "Security headers", "Company profile"]) assert.equal(B.guarded(n), false, n);
  for (const n of ["WHOIS", "RDAP", "Subdomains", "Wayback", "engine:CertSpotter", "tool:subfinder"]) assert.ok(B.guarded(n), n);
});
