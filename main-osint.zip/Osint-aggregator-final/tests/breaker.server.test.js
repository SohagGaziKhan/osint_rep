// Circuit breaker end to end: the offline mock makes WHOIS fail on every scan (a source that cannot be reached).
const test = require("node:test"), assert = require("node:assert"), { spawn } = require("node:child_process"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const PORT = 5396, B = `http://127.0.0.1:${PORT}`; let srv, cookie = "";
const call = (m, u, body) => fetch(B + u, { method: m, headers: { "Content-Type": "application/json", Origin: B, Cookie: cookie }, body: body ? JSON.stringify(body) : undefined });
const scan = async () => (await call("POST", "/api/recon", { domain: "example.com", consent: true, refresh: true })).json();
const ev = (r, c) => r.execution.events.filter((e) => e.collector === c).map((e) => e.type);
test.before(async () => { srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, ".."), env: { ...process.env, PORT, BREAKER_FAILURES: "2", BREAKER_COOLDOWN_SEC: "5", RATE_LIMIT: "10", DATA_DIR: fs.mkdtempSync(os.tmpdir() + "/bk-") }, stdio: "ignore" });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(B + "/api/health")).ok) break; } catch {} await new Promise((r) => setTimeout(r, 250)); }
  const r = await call("POST", "/api/auth/register", { email: "b@t.com", password: "password-1234", name: "B" }); cookie = r.headers.getSetCookie().map((x) => x.split(";")[0]).join("; "); });
test.after(() => srv && srv.kill());
test("a source that keeps failing is skipped, reported honestly, then tried once after the cooldown", async () => {
  const s1 = await scan(), s2 = await scan(); assert.ok(ev(s1, "WHOIS").includes("collector_failed") && ev(s2, "WHOIS").includes("collector_failed"));
  const s3 = await scan(); assert.deepEqual(ev(s3, "WHOIS"), ["collector_skipped"], "third scan skips WHOIS"); assert.match(s3.execution.events.find((e) => e.type === "collector_skipped").error, /circuit open/);
  assert.ok(s3.subdomains.length > 0 && s3.rdap && !s3.rdap.error, "other sources are not affected");
  const src = (await (await call("GET", "/api/sources")).json()).sources.find((x) => x.collector === "WHOIS"); assert.equal(src.circuit.open, true); assert.ok(src.circuit.retryInSec > 0);
  assert.equal((await (await call("GET", "/api/dashboard")).json()).modules.find((m) => m.collector === "WHOIS").runs, 2, "a skipped run is not counted as a run");
  await new Promise((r) => setTimeout(r, 5500)); const s4 = await scan(); assert.ok(ev(s4, "WHOIS").includes("collector_started"), "one trial after the cooldown");
  assert.equal((await (await call("GET", "/api/sources")).json()).sources.find((x) => x.collector === "WHOIS").circuit.open, true, "a failed trial re-opens it");
});
