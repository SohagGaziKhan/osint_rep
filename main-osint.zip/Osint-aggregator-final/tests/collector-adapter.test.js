const test = require("node:test");
const assert = require("node:assert");
const { createCollector, runCollector } = require("../lib/collectorAdapter");

const circuit = (open = false) => ({
  guarded: () => true,
  allow: () => !open,
  failures: () => 3,
  retryIn: () => 30,
  countable: () => true,
  success: () => {},
  failure: () => {},
});

test("collector adapter validates its contract", () => {
  assert.throws(() => createCollector({ id: "", collect() {} }), /id is required/);
  assert.throws(() => createCollector({ id: "DNS" }), /collect function/);
  assert.throws(() => createCollector({ id: "DNS", collect() {}, retries: -1 }), /retries/);
});

test("collector adapter normalizes success, retries and failure metadata", async () => {
  let calls = 0;
  const adapter = createCollector({
    id: "DNS",
    retries: 1,
    timeoutMs: 100,
    collect: async ({ domain }) => {
      calls++;
      if (calls === 1) throw new Error("temporary error");
      return { domain, records: ["192.0.2.1"] };
    },
  });
  const result = await runCollector(adapter, { domain: "example.com" });
  assert.deepStrictEqual([result.id, result.ok, result.skipped, result.attempts], ["DNS", true, false, 2]);
  assert.deepStrictEqual(result.value, { domain: "example.com", records: ["192.0.2.1"] });
  assert.equal(result.error, null);
});

test("collector adapter reports timeouts and skips open circuits", async () => {
  let starts = 0, skips = 0, finishes = 0;
  const timed = await runCollector(createCollector({
    id: "RDAP",
    retries: 0,
    timeoutMs: 5,
    collect: () => new Promise((resolve) => setTimeout(() => resolve({ ok: true }), 20)),
  }), null, { onStart: () => starts++, onFinish: () => finishes++ });
  assert.equal(timed.ok, false);
  assert.equal(timed.error, "timed out");
  assert.deepStrictEqual([starts, finishes], [1, 1]);

  const skipped = await runCollector(createCollector({ id: "RDAP", collect: () => assert.fail("must not run") }), null, {
    circuit: circuit(true),
    onSkip: (r) => { skips++; assert.match(r.error, /circuit open/); },
  });
  assert.deepStrictEqual([skipped.ok, skipped.skipped, skipped.attempts, skips], [false, true, 0, 1]);
});
