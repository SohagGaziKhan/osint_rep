// End-to-end API test on an OFFLINE mock (test data only). Starts the real server on a temp data dir.
const test = require("node:test"), assert = require("node:assert"), { spawn } = require("node:child_process"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const PORT = 5390, B = `http://127.0.0.1:${PORT}`; let srv;
const jar = {}; const call = async (who, m, u, body) => { const r = await fetch(B + u, { method: m, headers: { "Content-Type": "application/json", Origin: B, Cookie: jar[who] || "" }, body: body ? JSON.stringify(body) : undefined });
  const c = r.headers.getSetCookie(); if (c.length) jar[who] = c.map((x) => x.split(";")[0]).join("; "); return r; };
test.before(async () => { srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, ".."), env: { ...process.env, PORT, DATA_DIR: fs.mkdtempSync(os.tmpdir() + "/api-") }, stdio: "ignore" }); for (let i = 0; i < 40; i++) { try { if ((await fetch(B + "/api/health")).ok) return; } catch {} await new Promise((r) => setTimeout(r, 250)); } throw new Error("server did not start"); });
test.after(() => srv && srv.kill());
test("scan -> saved report -> ownership, dashboard, exports, sources", async () => {
  for (const [w, e] of [["a", "a@t.com"], ["b", "b@t.com"]]) assert.equal((await call(w, "POST", "/api/auth/register", { email: e, password: "password-1234", name: w })).status, 200);
  assert.equal((await call("a", "POST", "/api/recon", { domain: "example.com" })).status, 400, "consent required");
  assert.equal((await call("a", "POST", "/api/recon", { domain: "localhost", consent: true })).status, 400, "internal target blocked");
  const scan = await (await call("a", "POST", "/api/recon", { domain: "example.com", consent: true })).json();
  assert.equal(scan.saved, true); assert.ok(scan.subdomainStatus.every((s) => Array.isArray(s.sources) && s.sources.length), "every subdomain keeps its discovery source");
  assert.ok(scan.subdomainDiscoveredCount >= scan.subdomainCheckedCount);
  assert.ok(scan.subdomainStatus.every((s) => Array.isArray(s.ipv6) && typeof s.resolutionChecked === "boolean"));
  assert.equal(scan.rdap.registryDomainId, "D123-EXAMPLE"); assert.equal(scan.rdap.registrarIanaId, "123");
  assert.ok(scan.subdomainProviders["crt.sh"]);
  assert.ok(scan.emailAuth.spf && scan.risk.findings.length); assert.ok(scan.evidence.every((e) => e.status));
  const list = (await (await call("a", "GET", "/api/reports")).json()).reports; assert.equal(list.length, 1);
  assert.equal((await call("a", "GET", "/api/reports/" + list[0].id)).status, 200);
  assert.equal((await call("b", "GET", "/api/reports/" + list[0].id)).status, 404, "other user cannot read it");
  assert.equal((await call("nobody", "GET", "/api/reports/" + list[0].id)).status, 401);
  await call("a", "POST", "/api/recon", { domain: "example.com", consent: true }); // cache hit
  assert.equal((await (await call("a", "GET", "/api/reports")).json()).reports.length, 1, "cache hit must not duplicate the report");
  const d = await (await call("a", "GET", "/api/dashboard")).json(); assert.deepEqual([d.total, d.completed, d.failed, d.reports], [2, 2, 0, 1]);
  assert.equal((await (await call("b", "GET", "/api/dashboard")).json()).total, 0);
  for (const f of ["docx", "pdf"]) { const r = await call("a", "POST", "/api/export/" + f, { report: scan }); assert.equal(r.status, 200); const buf = Buffer.from(await r.arrayBuffer()); assert.ok(buf.slice(0, 4).toString("latin1").startsWith(f === "pdf" ? "%PDF" : "PK")); }
  assert.equal((await call("nobody", "POST", "/api/export/pdf", { report: scan })).status, 200, "guest export of the current result is allowed by policy (GUEST_EXPORT=0 disables it; see guest.test.js)");
});
test("SSRF variants, bad report ids and bad IP targets are rejected", async () => {
  for (const t of ["127.0.0.1", "localhost", "169.254.169.254", "10.0.0.1", "192.168.1.1", "[::1]", "0.0.0.0", "2130706433", "0x7f000001", "localhost.localdomain", "example.com@127.0.0.1", "172.16.0.5"]) assert.notEqual((await call("a", "POST", "/api/recon", { domain: t, consent: true })).status, 200, "recon accepted " + t);
  for (const t of ["127.0.0.1", "10.1.1.1", "169.254.169.254", "::1", "192.168.0.1"]) assert.notEqual((await call("a", "POST", "/api/ipscan", { ip: t, consent: true })).status, 200, "ipscan accepted " + t);
  for (const id of ["../../etc/passwd", "1%2F..%2F..", "1;drop", "99999999999999999999"]) assert.ok([400, 404].includes((await call("a", "GET", "/api/reports/" + id)).status), "report id " + id);
  const d = await (await call("a", "GET", "/api/dashboard")).json(); assert.ok(d.coverage && typeof d.coverage === "object");
});
test("findings carry an id and a verification label; engine families report real status", async () => {
  const rep = await (await call("a", "POST", "/api/recon", { domain: "example.com", consent: true })).json();
  assert.ok(rep.risk.findings.length && rep.risk.findings.every((f) => /^F-\d{3}$/.test(f.id) && ["VERIFIED", "PARTIALLY VERIFIED", "UNVERIFIED"].includes(f.verification)));
  assert.ok(rep.evidence.length && rep.evidence.every((e) => ["VERIFIED", "UNVERIFIED", "NOT FOUND", "FAILED", "PARTIAL", "SOURCE UNAVAILABLE"].includes(e.classification)), "every evidence row carries one of the six statuses");
  assert.ok(rep.risk.findings.filter((f) => !f.verified).every((f) => f.verification === "UNVERIFIED"));
  const er = await (await call("a", "GET", "/api/engine-registry")).json(); assert.equal(er.families.length, 12); assert.equal(er.families[0].status, "ok"); assert.ok(er.families[3].status.startsWith("not run"));
  assert.equal((await call("nobody", "GET", "/api/engine-registry")).status, 401);
});
test("report sections follow the A-P order; module extract and IP lookup reports work", async () => {
  const rep = await (await call("a", "POST", "/api/recon", { domain: "example.com", consent: true })).json();
  const { buildModel } = require("../lib/reportModel"); const t = buildModel(rep).sections.map((s) => s.title.replace(/^\d+\.\s*/, ""));
  const pos = (k) => t.findIndex((x) => x.startsWith(k)); assert.equal(t[0], "Executive Summary");
  const order = ["Investigation Methodology", "Domain & DNS", "Subdomain", "Public Email", "Social", "Historical", "Public Documents", "Google Dorking", "Threat", "Entity Relationship", "Findings & Recommendations", "Evidence", "Coverage", "Investigation Summary"].map(pos);
  assert.ok(order.every((p) => p >= 0) && order.every((p, i) => i === 0 || p > order[i - 1]), "order " + order.join(","));
  const r = await call("a", "POST", "/api/export/pdf", { report: rep, only: ["Subdomain"] }); assert.equal(r.status, 200); assert.match(r.headers.get("content-disposition"), /-module\.pdf/);
  const full = await call("a", "POST", "/api/export/pdf", { report: rep }); assert.ok((await r.arrayBuffer()).byteLength < (await full.arrayBuffer()).byteLength, "module extract is smaller than the full report");
  const ip = await call("a", "POST", "/api/ipscan", { ip: "93.184.216.34", consent: true }); assert.equal(ip.status, 200);
  const list = (await (await call("a", "GET", "/api/reports")).json()).reports; const item = list.find((x) => x.kind === "ip"); assert.ok(item, "IP lookup saved");
  assert.equal((await (await call("a", "GET", "/api/reports/" + item.id)).json()).kind, "ip");
  const dd = await (await call("a", "GET", "/api/dashboard")).json(); assert.ok(dd.recent.some((x) => x.kind === "ip" && x.status === "completed"), "IP lookup must be counted on the dashboard"); assert.ok(list.some((x) => x.kind === "domain"));
});
test("execution timeline is real and consistent; collector runs and audit log are stored per user", async () => {
  const rep = await (await call("a", "POST", "/api/recon", { domain: "example.com", consent: true, refresh: true })).json(); const ev = rep.execution.events;
  assert.equal(ev[0].type, "investigation_started"); assert.equal(ev[ev.length - 1].type, "investigation_finished"); assert.ok(ev.some((e) => e.type === "verification_applied"));
  const started = ev.filter((e) => e.type === "collector_started").map((e) => e.collector), ended = ev.filter((e) => /^collector_(finished|failed)$/.test(e.type)).map((e) => e.collector);
  assert.ok(started.length >= 18, "every collector is recorded: " + started.length); assert.deepEqual([...started].sort(), [...ended].sort(), "each started collector finished or failed exactly once");
  assert.ok(ev.every((e, i) => i === 0 || Date.parse(e.at) >= Date.parse(ev[i - 1].at)), "timestamps never go backwards"); assert.ok(ev.filter((e) => e.type !== "investigation_started" && e.collector).every((e) => e.type === "collector_started" || e.ms >= 0));
  const d = await (await call("a", "GET", "/api/dashboard")).json(); assert.ok(d.modules.length >= 18 && d.modules.every((m) => m.runs >= 1 && m.ok <= m.runs), "dashboard module usage comes from stored collector runs");
  const au = (await (await call("a", "GET", "/api/audit")).json()).entries.map((e) => e.action); for (const a of ["scan_completed", "export", "ip_lookup"]) assert.ok(au.includes(a), "audit has " + a);
  assert.ok(!(await (await call("b", "GET", "/api/audit")).json()).entries.some((e) => e.action === "scan_completed"), "another user's audit log does not contain user a's scans");
  assert.equal((await call("nobody", "GET", "/api/audit")).status, 401);
  const t = require("../lib/reportModel").buildModel(rep).sections.map((s) => s.title.replace(/^\d+\.\s*/, "")); assert.equal(t.indexOf("Investigation Timeline"), t.indexOf("Investigation Methodology") + 1, "timeline follows the methodology");
});
test("every finding carries an evidence record; the dashboard and the appendix use it; source health leaks no target", async () => {
  assert.equal((await call("c", "POST", "/api/auth/register", { email: "c@t.com", password: "password-1234", name: "c" })).status, 200);
  const rep = await (await call("c", "POST", "/api/recon", { domain: "example.com", consent: true, refresh: true })).json(); const fl = rep.risk.findings;
  assert.ok(fl.length && fl.every((f) => f.id && f.verification && f.method && f.limitation && f.verifiedAt && f.collectedAt && f.firstSeenAt && f.lastSeenAt && f.freshness === "NEW" && f.availability === "OBSERVED" && Array.isArray(f.related)), "evidence and freshness fields on every finding");
  assert.ok(fl.filter((f) => !f.verified).every((f) => /Third-party|heuristic/i.test(f.limitation) && f.verification === "UNVERIFIED"), "unverified findings say so in their limitation");
  assert.ok(fl.every((f) => f.related.every((id) => fl.some((o) => o.id === id && o.id !== f.id && o.source === f.source))), "related ids point to other findings from the same source");
  const sections = require("../lib/reportModel").buildModel(rep).sections, ap = sections.find((s) => /Finding Evidence Appendix/.test(s.title));
  assert.equal(ap.bullets.length, fl.length); assert.ok(ap.bullets.every((b, i) => b.startsWith(fl[i].id) && /limitation:/.test(b)));
  const d = await (await call("c", "GET", "/api/dashboard")).json(); assert.equal(typeof d.verified, "number"); assert.ok(d.verified >= fl.filter((f) => f.verification === "VERIFIED").length);
  assert.ok(d.latestFindings.length > 0 && d.latestFindings.length <= 6 && d.latestFindings.every((f) => f.id && f.domain)); assert.ok(d.recentReports.length > 0 && d.recentReports.length <= 5);
  assert.ok(["high", "medium", "low"].includes(d.latestFindings[0].sev) && d.latestFindings[0].sev === "high", "highest severity first");
  const s = await (await call("b", "GET", "/api/sources")).json(); assert.ok(s.sources.length >= 18);
  assert.ok(s.sources.every((x) => ["Available", "Rate Limited", "Blocked", "Timeout", "Unavailable", "Error"].includes(x.state) && x.runs >= 1 && x.ok <= x.runs));
  assert.ok(!JSON.stringify(s).includes("example.com"), "another user's target never appears in source health"); assert.equal((await call("nobody", "GET", "/api/sources")).status, 401);
});
test("findings are stored per investigation: filters, paging, isolation, and the dashboard shows the newest scan's findings", async () => {
  const before = (await (await call("c", "GET", "/api/findings?limit=1")).json()).total;
  const rep = await (await call("c", "POST", "/api/recon", { domain: "example.com", consent: true, refresh: true })).json(), n = rep.risk.findings.length;
  const all = await (await call("c", "GET", "/api/findings?limit=100")).json(); assert.equal(all.total, before + n, "every finding of the new scan was stored once");
  const mine = all.findings.filter((f) => f.investigationId === rep.investigationId); assert.equal(mine.length, n); assert.ok(mine.every((f) => f.id && f.verification && f.method && f.limitation && f.firstSeenAt && f.lastSeenAt && f.freshness && f.availability));
  const hi = await (await call("c", "GET", "/api/findings?sev=high&limit=100")).json(); assert.ok(hi.total > 0 && hi.findings.every((f) => f.sev === "high"));
  const ver = await (await call("c", "GET", "/api/findings?ver=VERIFIED&limit=100")).json(); assert.ok(ver.findings.every((f) => f.verification === "VERIFIED"));
  const q = await (await call("c", "GET", "/api/findings?q=CVE&limit=100")).json(); assert.ok(q.total > 0 && q.findings.every((f) => /CVE/i.test(f.msg + f.source + f.id)));
  const pg = await (await call("c", "GET", "/api/findings?limit=2&offset=" + (all.total - 1))).json(); assert.equal(pg.findings.length, 1); assert.equal((await (await call("c", "GET", "/api/findings?offset=100000")).json()).findings.length, 0);
  assert.equal((await (await call("b", "GET", "/api/findings")).json()).total, 0, "another user sees none of these"); assert.equal((await call("nobody", "GET", "/api/findings")).status, 401);
  const d = await (await call("c", "GET", "/api/dashboard")).json(); assert.equal(d.latestFindings.length, 6); assert.ok(d.latestFindings.every((f) => f.domain === "example.com"));
});
