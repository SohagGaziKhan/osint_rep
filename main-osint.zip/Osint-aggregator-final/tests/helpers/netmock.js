// Deterministic OFFLINE network mock for tests. Usage:  node -r ./tests/helpers/netmock.js server.js
// It patches axios, dns, tls and whois so a scan returns realistic, fully populated data with no internet.
// The data below is TEST DATA ONLY (example.com / RFC 5737 + 2606:4700 doc-style values). Never ship it as real results.
const dns = require("dns"), tls = require("tls"), { EventEmitter } = require("events");
const axios = require("axios"), whois = require("whois");

const IPV4 = "93.184.216.34";           // example.com's historically published address
const SUBS = ["www", "mail", "api", "dev", "old-shop", "blog"];
const EVIL = !!process.env.MOCK_EVIL;
const HOME = `<!doctype html><html lang="en"><head><title>${EVIL ? 'Example</title><img src=x onerror=window.__xss=1>' : 'Example Co'}</title>
<meta name="description" content="Example Co builds things."><meta property="og:site_name" content="${EVIL ? '\"><img src=x onerror=window.__xss=3>' : 'Example Co'}">
<meta property="og:image" content="/img/og.png"><link rel="canonical" href="https://example.com/"><link rel="icon" href="/favicon.ico">
<link rel="alternate" type="application/rss+xml" href="/feed.xml">
<script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"${EVIL ? '<img src=x onerror=window.__xss=2>' : 'Example Co'}","url":"https://example.com",
"logo":"https://example.com/logo.png","foundingDate":"2015","sameAs":["https://www.linkedin.com/company/exampleco","https://github.com/exampleco"],
"address":{"@type":"PostalAddress","streetAddress":"1 Test St","addressLocality":"Dhaka","addressCountry":"BD"}}</script></head>
<body><a href="/about">About</a><a href="/contact">Contact</a><a href="/careers">Careers</a><a href="/privacy">Privacy</a>
<a href="mailto:hello@example.com">Mail</a><a href="tel:+8801000000000">Call</a>
<a href="https://www.facebook.com/exampleco">FB</a><a href="https://twitter.com/exampleco">X</a><a href="/files/brochure.pdf">PDF</a>
<img src="/a.png" alt="a"><img src="/b.png"><div class="wp-content"></div></body></html>`;
const enotfound = (host) => Object.assign(new Error(`getaddrinfo ENOTFOUND ${host}`), { code: "ENOTFOUND" });

// ---- DNS
const P = dns.promises, host = (h) => String(h).toLowerCase();
const known = (h) => host(h) === "example.com" || SUBS.some((s) => host(h) === `${s}.example.com`);
P.resolve = async (h, type = "A") => {
  h = host(h);
  if (h === "old-shop.example.com" && type === "A") throw Object.assign(new Error("queryA ENODATA"), { code: "ENODATA" });
  if (!known(h)) throw enotfound(h);
  const t = { A: [IPV4], AAAA: ["2606:2800:220:1:248:1893:25c8:1946"], MX: [{ priority: 10, exchange: "aspmx.l.google.com" }], NS: ["a.iana-servers.net", "b.iana-servers.net"],
    TXT: [["v=spf1 include:_spf.google.com ~all"]], SOA: { nsname: "ns.icann.org", hostmaster: "noc.dns.icann.org", serial: 1, refresh: 7200, retry: 3600, expire: 1209600, minttl: 3600 }, CNAME: [] }[type];
  if (!t || (Array.isArray(t) && !t.length)) throw Object.assign(new Error(`query${type} ENODATA`), { code: "ENODATA" });
  return t;
};
P.resolve4 = async (h) => { if (host(h) === "old-shop.example.com") throw Object.assign(new Error("ENODATA"), { code: "ENODATA" }); if (!known(h)) throw enotfound(h); return [IPV4]; };
P.resolve6 = async (h) => { if (host(h) === "old-shop.example.com") throw Object.assign(new Error("ENODATA"), { code: "ENODATA" }); if (!known(h)) throw enotfound(h); return ["2606:2800:220:1:248:1893:25c8:1946"]; };
P.resolveCname = async (h) => { if (host(h) === "old-shop.example.com") return ["example-shop.myshopify.com"]; throw Object.assign(new Error("ENODATA"), { code: "ENODATA" }); };
P.resolveTxt = async (h) => { h = host(h); if (h === "example.com") return [["v=spf1 include:_spf.google.com ~all"]]; if (h === "_dmarc.example.com") return [["v=DMARC1; p=none; rua=mailto:d@example.com"]];
  if (h === "google._domainkey.example.com") return [["v=DKIM1; k=rsa; p=MIGf"]]; throw Object.assign(new Error("ENODATA"), { code: "ENODATA" }); };
P.resolveCaa = async () => { throw Object.assign(new Error("ENODATA"), { code: "ENODATA" }); };
P.reverse = async () => ["93.184.216.34.bc.example.net"];

// ---- TLS
tls.connect = (opts, cb) => {
  const s = new EventEmitter(); s.getProtocol = () => "TLSv1.3"; s.authorized = true; s.end = () => {}; s.destroy = () => {};
  s.getPeerCertificate = () => ({ subject: { CN: "example.com" }, issuer: { O: "Test CA" }, valid_from: "Jan  1 00:00:00 2026 GMT", valid_to: "Jan  1 00:00:00 2027 GMT",
    subjectaltname: "DNS:example.com, DNS:www.example.com" });
  setImmediate(cb); return s;
};

// ---- WHOIS
whois.lookup = (d, o, cb) => cb(null, `Domain Name: EXAMPLE.COM\nRegistry Domain ID: D123-EXAMPLE\nRegistrar: Test Registrar, Inc.\nRegistrar IANA ID: 123\nRegistrar WHOIS Server: whois.example.test\nRegistrar URL: https://registrar.example.test\nCreation Date: 1995-08-14T04:00:00Z\nUpdated Date: 2026-08-14T07:01:00Z\nRegistry Expiry Date: 2027-08-13T04:00:00Z\nDomain Status: clientTransferProhibited\nName Server: A.IANA-SERVERS.NET\nName Server: B.IANA-SERVERS.NET\n`);

// ---- HTTP (axios)
const ok = (data, headers = {}) => ({ status: 200, data, headers, request: { res: { responseUrl: "https://example.com/" } } });
const missing = (u) => { const e = new Error(`Request failed with status code 404 (${u})`); e.response = { status: 404 }; throw e; };
axios.get = async (url, o = {}) => {
  const u = String(url); if (+process.env.MOCK_SLOW_MS) await new Promise((r) => setTimeout(r, +process.env.MOCK_SLOW_MS)); // lets tests cancel a scan mid-way
  if (u.startsWith("https://crt.sh")) return ok(SUBS.map((s) => ({ name_value: `${s}.example.com\nexample.com` })));
  if (u.includes("otx.alienvault.com")) return ok({ passive_dns: [{ hostname: "dev.example.com" }, { hostname: "staging.example.com" }] });
  if (u.includes("jldc.me/anubis")) return ok(["api.example.com", "blog.example.com"]);
  if (u.startsWith("https://rdap.org")) return ok({ ldhName: "example.com", handle: "D123-EXAMPLE", port43: "whois.example.test",
    events: [{ eventAction: "registration", eventDate: "1995-08-14T04:00:00Z" }, { eventAction: "expiration", eventDate: "2027-08-13T04:00:00Z" }, { eventAction: "last changed", eventDate: "2026-08-14T07:01:00Z" }],
    entities: [{ roles: ["registrar"], publicIds: [{ type: "IANA Registrar ID", identifier: "123" }], vcardArray: ["vcard", [["fn", {}, "text", "Test Registrar, Inc."]]] }],
    nameservers: [{ ldhName: "A.IANA-SERVERS.NET" }], status: ["client transfer prohibited"], secureDNS: { delegationSigned: true } });
  if (u.includes("prefix-overview")) return ok({ data: { resource: "93.184.216.0/24", asns: [{ asn: 15133, holder: "EDGECAST - Edgecast Networks" }] } });
  if (u.includes("maxmind-geo-lite")) return ok({ data: { located_resources: [{ locations: [{ country: "US", city: "Los Angeles" }] }] } });
  if (u.startsWith("https://internetdb.shodan.io")) return ok({ ports: [80, 443, 3306], vulns: ["CVE-2021-44228", "CVE-2019-0001"], hostnames: ["example.com"], tags: ["cdn"], cpes: ["cpe:/a:nginx:nginx"] });
  if (u.includes("api.certspotter.com")) return ok([{ dns_names: ["cert1.example.com", "*.example.com", "other.net"] }]);
  if (u.includes("api.hackertarget.com")) return ok("ht1.example.com,93.184.216.34\nwww.example.com,93.184.216.34\n");
  if (u.includes("urlscan.io")) return ok({ results: [{ page: { domain: "us1.example.com" } }, { page: { domain: "elsewhere.org" } }] });
  if (u.includes("web.archive.org/cdx") && o.params && o.params.url) return ok([["original"], ["http://wb1.example.com/x"], ["http://other.net/y"]]);
  if (u.includes("web.archive.org/cdx")) {
    if (o.params && o.params.matchType === "domain") return ok([["original"], ["https://example.com/backup.zip"], ["https://example.com/admin/login"], ["https://example.com/"]]);
    return ok([["timestamp", "original", "statuscode"], ["20050101000000", "http://example.com/", "200"], ["20150601000000", "http://example.com/", "200"], ["20260101000000", "https://example.com/", "200"]]);
  }
  if (u.includes("known_exploited_vulnerabilities")) return ok({ vulnerabilities: [{ cveID: "CVE-2021-44228" }] });
  if (u.includes("openphish.com")) return ok("https://login.example.com/verify\nhttps://other.test/x\n");
  if (u.includes("feodotracker")) return ok("# list\n203.0.113.9\n");
  if (u.includes("api.github.com/users/exampleco/repos")) return ok([{ name: "tool", stargazers_count: 12, language: "JavaScript", pushed_at: "2026-09-01T00:00:00Z" }]);
  if (u.includes("api.github.com/users/exampleco")) return ok({ login: "exampleco", html_url: "https://github.com/exampleco", type: "Organization", name: "Example Co", blog: "https://example.com", public_repos: 5, followers: 42, created_at: "2018-01-01T00:00:00Z" });
  if (u.includes("wikidata.org")) return ok({ search: [{ id: "Q1" }], entities: { Q1: { labels: { en: { value: "Example Co" } }, descriptions: { en: { value: "test" } }, claims: { P856: [{ mainsnak: { datavalue: { value: "https://example.com" } } }] } } } });
  if (/linkedin|facebook|twitter|github\.com\/exampleco$/.test(u)) return { status: 200, data: "Example Co example.com", headers: {} };
  if (u.endsWith("/robots.txt")) return ok("User-agent: *\nDisallow: /admin\nSitemap: https://example.com/sitemap.xml\n");
  if (u.endsWith("/sitemap.xml")) return ok("<urlset><url><loc>https://example.com/</loc></url><url><loc>https://example.com/about</loc></url></urlset>");
  if (u.endsWith("/.well-known/security.txt")) return { status: 404, data: "", headers: {} };
  if (/^https:\/\/example\.com\/?$/.test(u)) return ok(HOME, { server: "nginx", "set-cookie": ["sid=abc; Path=/", "pref=1; Secure; HttpOnly; SameSite=Lax"], "strict-transport-security": "max-age=1", "x-content-type-options": "nosniff" });
  return missing(u);
};
axios.post = async () => ok({ query_status: "no_results", url_count: 0 });
process.env.BREAKER_FAILURES = process.env.BREAKER_FAILURES || "1000"; // the offline mock fails some sources on every scan on purpose; tests that need the breaker set their own value
console.log("[netmock] offline network mock ACTIVE - results are TEST DATA");
