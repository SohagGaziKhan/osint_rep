const test = require("node:test"), assert = require("node:assert"), { classify } = require("../lib/classification");
test("module outcomes map to the six statuses", () => {
  const c = (module, status) => classify({ module, status });
  assert.equal(c("Domain & DNS", "ok"), "VERIFIED"); assert.equal(c("TLS & headers", "ok"), "VERIFIED");
  assert.equal(c("Ports & CVEs", "ok"), "UNVERIFIED"); assert.equal(c("Threat feeds", "ok"), "UNVERIFIED"); assert.equal(c("Company & social", "ok"), "UNVERIFIED");
  assert.equal(c("Subdomains", "no data returned"), "NOT FOUND");
  assert.equal(c("Archives", "failed (getaddrinfo ENOTFOUND web.archive.org)"), "SOURCE UNAVAILABLE"); assert.equal(c("Threat feeds", "blocked (a source refused automated queries)"), "SOURCE UNAVAILABLE");
  assert.equal(c("Email security", "failed (DNS lookup failed (ENOTFOUND))"), "SOURCE UNAVAILABLE"); assert.equal(c("Archives", "failed (unexpected token)"), "FAILED");
  assert.equal(c("Subdomains", "ok (some commands failed)"), "PARTIAL"); assert.equal(c("Subdomains", "ok (some sources blocked)"), "PARTIAL"); assert.equal(c("Subdomains", "ok"), "UNVERIFIED");
});
test("a failed or empty module is never VERIFIED", () => { for (const s of ["failed (x)", "no data returned", "blocked (x)"]) assert.notEqual(classify({ module: "Domain & DNS", status: s }), "VERIFIED"); });
test("a check that never ran is FAILED, not NOT FOUND", () => { assert.equal(classify({ module: "IP & ASN", status: "not run: no IP address was resolved" }), "FAILED"); });
