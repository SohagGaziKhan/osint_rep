const test = require("node:test"), assert = require("node:assert"), { find } = require("../lib/disagreements");
test("same registrar written differently and dates within a day are NOT a disagreement", () => {
  assert.deepEqual(find({ whois: { registrar: "MarkMonitor Inc.", expiryDate: "2027-08-13T04:00:00Z" }, rdap: { registrar: "MarkMonitor, Inc", expires: "2027-08-13T23:00:00Z" } }), []);
  assert.deepEqual(find({ whois: { registrar: "GoDaddy" }, rdap: { registrar: "GoDaddy.com, LLC" } }), []);
});
test("different registrar and expiry are kept side by side and labelled CONTRADICTED", () => {
  const r = find({ whois: { registrar: "Alpha Registrar", expiryDate: "2027-01-01" }, rdap: { registrar: "Beta Names", expires: "2027-03-01" } });
  assert.deepEqual(r.map((x) => x.field), ["registrar", "expiry date"]); assert.ok(r.every((x) => x.verification === "CONTRADICTED" && x.values.length === 2));
  assert.deepEqual(r[0].values.map((v) => v.value), ["Beta Names", "Alpha Registrar"]);
});
test("a missing or failed side never produces a disagreement", () => {
  assert.deepEqual(find({ whois: { error: "x" }, rdap: { registrar: "A" } }), []); assert.deepEqual(find({ whois: { registrar: "A" }, rdap: {} }), []); assert.deepEqual(find({}), []);
});
