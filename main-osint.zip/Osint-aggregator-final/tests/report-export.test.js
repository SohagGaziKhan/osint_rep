const test = require("node:test");
const assert = require("node:assert");
const { inflateRawSync, inflateSync } = require("node:zlib");
const { buildModel } = require("../lib/reportModel");
const { toDocx, toPdf } = require("../lib/reportExport");
const graphImage = require("../lib/graphImage");

function zipEntry(zip, target) {
  const end = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.notEqual(end, -1, "ZIP end record exists");
  const entries = zip.readUInt16LE(end + 10), start = zip.readUInt32LE(end + 16);
  let at = start;
  for (let i = 0; i < entries; i++) {
    assert.equal(zip.readUInt32LE(at), 0x02014b50, "central directory entry");
    const method = zip.readUInt16LE(at + 10), compressed = zip.readUInt32LE(at + 20);
    const nameLen = zip.readUInt16LE(at + 28), extraLen = zip.readUInt16LE(at + 30), commentLen = zip.readUInt16LE(at + 32);
    const name = zip.toString("utf8", at + 46, at + 46 + nameLen), local = zip.readUInt32LE(at + 42);
    if (name === target) {
      const localNameLen = zip.readUInt16LE(local + 26), localExtraLen = zip.readUInt16LE(local + 28);
      const dataAt = local + 30 + localNameLen + localExtraLen, data = zip.subarray(dataAt, dataAt + compressed);
      return method === 0 ? data : method === 8 ? inflateRawSync(data) : assert.fail(`Unsupported ZIP method ${method}`);
    }
    at += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

function zipNames(zip) {
  const end = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  const entries = zip.readUInt16LE(end + 10);
  let at = zip.readUInt32LE(end + 16);
  const names = [];
  for (let i = 0; i < entries; i++) {
    const nameLen = zip.readUInt16LE(at + 28), extraLen = zip.readUInt16LE(at + 30), commentLen = zip.readUInt16LE(at + 32);
    names.push(zip.toString("utf8", at + 46, at + 46 + nameLen));
    at += 46 + nameLen + extraLen + commentLen;
  }
  return names;
}

function pdfText(pdf) {
  const source = pdf.toString("latin1"), texts = [];
  let at = 0;
  while ((at = source.indexOf("stream", at)) !== -1) {
    let start = at + 6;
    if (source.slice(start, start + 2) === "\r\n") start += 2;
    else if (source[start] === "\n") start++;
    const end = source.indexOf("endstream", start);
    if (end === -1) break;
    try {
      const decoded = inflateSync(pdf.subarray(start, end)).toString("latin1");
      for (const match of decoded.matchAll(/<([0-9A-F]+)> Tj/g)) texts.push(Buffer.from(match[1], "hex").toString("latin1"));
    } catch {}
    at = end + 9;
  }
  return texts.join(" ");
}

const report = () => buildModel({
  domain: "example.com",
  generatedAt: "2026-01-01T00:00:00.000Z",
  risk: { level: "Low", findings: [] },
  graph: {
    nodes: [{ id: "example.com", type: "domain" }, { id: "192.0.2.1", type: "ip" }],
    edges: [{ from: "example.com", to: "192.0.2.1", label: "resolves to", source: "DNS" }],
  },
});

test("DOCX export contains a repeating watermark and relationship graph images", async () => {
  const docx = await toDocx(report());
  const header = zipEntry(docx, "word/header1.xml").toString("utf8");
  const document = zipEntry(docx, "word/document.xml").toString("utf8");
  const names = zipNames(docx);
  const svgName = names.find((name) => /^word\/media\/.+\.svg$/.test(name));
  const pngName = names.find((name) => /^word\/media\/.+\.png$/.test(name));
  const svg = svgName && zipEntry(docx, svgName);
  const png = pngName && zipEntry(docx, pngName);
  assert.match(header, /w:pict|w:shape/);
  assert.match(header, /SOFTINZA OSINT/);
  assert.match(document, /Relationship graph/);
  assert.ok(svg && svg.toString("utf8").includes("<svg"));
  assert.ok(png && png.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])));
});

test("graph PNG fallback has valid dimensions and signature", () => {
  const png = graphImage.png({ nodes: [{ id: "example.com", type: "domain" }], edges: [] }, 320, 200);
  assert.deepStrictEqual([...png.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
  assert.equal(png.readUInt32BE(16), 320);
  assert.equal(png.readUInt32BE(20), 200);
});

test("PDF export renders report rows as a labeled table", async () => {
  const model = report();
  model.sections[0].rows = [["Test field", "Test value"]];
  const pdf = await toPdf(model);
  assert.equal(pdf.subarray(0, 4).toString(), "%PDF");
  const text = pdfText(pdf);
  assert.match(text, /Field/);
  assert.match(text, /Value/);
  assert.match(text, /Test field/);
  assert.match(text, /Test value/);
});
