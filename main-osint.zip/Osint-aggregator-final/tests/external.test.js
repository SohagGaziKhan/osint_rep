// Tests the adapter LOGIC with FAKE executables (the real tools are not installed in CI). It does not prove the real tools' output formats.
const test = require("node:test"), assert = require("node:assert"), fs = require("node:fs"), os = require("node:os"), path = require("node:path");
const dir = fs.mkdtempSync(os.tmpdir() + "/fake-"); const mk = (n, body) => fs.writeFileSync(path.join(dir, n), "#!/bin/sh\n" + body, { mode: 0o755 });
mk("subfinder", "echo api.example.com; echo API.example.com; echo evil.attacker.net; echo '*.example.com'; echo notexample.com; echo deep.sub.example.com\n");
mk("theHarvester", 'while [ $# -gt 0 ]; do [ "$1" = "-f" ] && out="$2"; shift; done\necho "noise https://other.org admin@other.org"\nprintf \'{"hosts":["h1.example.com:1.2.3.4","off.target.net"],"emails":["bob@example.com","eve@other.org"]}\' > "$out.json"\n');
mk("spiderfoot", `echo '[{"type":"INTERNET_NAME","data":"sf1.example.com"},{"type":"EMAILADDR","data":"carol@mail.example.com"},{"type":"INTERNET_NAME","data":"zzz.other.com"}]'\n`);
mk("recon-cli", 'echo "[*] Host: rn1.example.com"; echo "[*] Host: rn2.example.org" >&2\n');
process.env.PATH = dir + path.delimiter + process.env.PATH;
const X = require("../lib/externalTools");
test("disabled by default; names normalised; unknown ignored", () => { delete process.env.EXTERNAL_TOOLS; assert.deepEqual(X.enabled(), []); process.env.EXTERNAL_TOOLS = "Subfinder, recon-ng, bogus, theHarvester"; assert.deepEqual(X.enabled(), ["subfinder", "reconng", "theharvester"]); });
test("subfinder: only names under the target, deduplicated, no wildcards", async () => { const r = await X.run("subfinder", "example.com"); assert.equal(r.status, "ok"); assert.deepEqual(r.names.sort(), ["api.example.com", "deep.sub.example.com"]); });
test("theHarvester: reads its JSON file, drops off-target names/emails, strips :ip", async () => { const r = await X.run("theharvester", "example.com"); assert.equal(r.status, "ok"); assert.deepEqual(r.names, ["h1.example.com"]); assert.deepEqual(r.emails, ["bob@example.com"]); });
test("spiderfoot: hosts and emails kept only for the target; email domains are not mistaken for hosts", async () => { const r = await X.run("spiderfoot", "example.com"); assert.deepEqual(r.names, ["sf1.example.com"]); assert.deepEqual(r.emails, ["carol@mail.example.com"]); });
test("recon-ng: runs each configured module and keeps on-target hosts only", async () => { const r = await X.run("reconng", "example.com"); assert.equal(r.status, "ok"); assert.deepEqual(r.names, ["rn1.example.com"]); });
test("missing binary is reported, not thrown", async () => { assert.equal((await X.run("amass", "example.com")).status, "not installed"); });
test("unsafe domain values never reach a process", async () => { for (const d of ["a.com; rm -rf /", "-d evil.com", "x.com\nid", "../x"]) assert.equal((await X.run("subfinder", d)).status, "skipped"); });
test("unsafe env values fall back to defaults", () => { process.env.THEHARVESTER_SOURCES = "crtsh;rm -rf /"; assert.ok(X.TOOLS.theharvester.cmds("example.com", "/tmp/x")[0][1].includes("crtsh,otx,hackertarget,rapiddns")); delete process.env.THEHARVESTER_SOURCES; });
