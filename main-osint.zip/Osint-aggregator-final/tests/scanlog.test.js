process.env.DATA_DIR = require("fs").mkdtempSync(require("os").tmpdir() + "/sl-");
const test = require("node:test"), assert = require("node:assert"), db = require("../lib/db"), SL = require("../lib/scanLog");
const mk = (e) => Number(db.prepare("INSERT INTO users (email,name,pass,created_at) VALUES (?,?,?,?)").run(e, "x", "x", Date.now()).lastInsertRowid);

test("dashboard counts each scan once, ignores cached findings, and isolates users", () => {
  const a = mk("a@x.com"), b = mk("b@x.com");
  SL.record(a, { domain: "x.com", status: "completed", risk: "High", findings: 5 });
  SL.record(a, { domain: "x.com", status: "completed", risk: "High", findings: 5, cached: true });
  SL.record(a, { domain: "y.com", status: "failed" });
  SL.record(b, { domain: "z.com", status: "completed", risk: "Low", findings: 1 });
  const d = SL.dashboard(a);
  assert.deepEqual([d.total, d.completed, d.failed, d.findings], [3, 2, 1, 5]);
  assert.equal(d.series.length, 14);
  assert.equal(d.series.reduce((s, x) => s + x.scans, 0), 3);
  assert.equal(SL.dashboard(b).total, 1);
});
test("empty account yields zeros and empty lists, not invented numbers", () => {
  const d = SL.dashboard(mk("c@x.com"));
  assert.deepEqual([d.total, d.completed, d.failed, d.findings, d.reports], [0, 0, 0, 0, 0]);
  assert.equal(d.recent.length, 0); assert.equal(d.trackedSince, null);
});
test("severity totals and 'completed with gaps' count fresh scans only", () => {
  const u = mk("d@x.com");
  SL.record(u, { domain: "a.com", status: "completed", findings: 3, sev: { high: 1, medium: 1, low: 1 }, partial: true });
  SL.record(u, { domain: "a.com", status: "completed", findings: 3, sev: { high: 1, medium: 1, low: 1 }, cached: true });
  const d = SL.dashboard(u); assert.deepEqual(d.severity, { high: 1, medium: 1, low: 1 }); assert.equal(d.partial, 1);
});
test("finding history tracks first/last seen and preserves prior findings when a source is unavailable", () => {
  const u = mk("history@x.com"), firstAt = new Date(Date.now() - 60000).toISOString();
  const finding = { id: "F-001", sev: "high", msg: "SSL certificate has expired", source: "TLS handshake with the target", confidence: "High", verification: "VERIFIED", collectedAt: firstAt };
  const first = { domain: "history.example", generatedAt: firstAt, investigationId: "INV-FIRST", risk: { findings: [finding] }, evidence: [] };
  SL.decorateFindings(u, first);
  SL.recordInvestigation(u, first);

  const now = new Date().toISOString();
  const second = { domain: "history.example", generatedAt: now, investigationId: "INV-SECOND", risk: { findings: [{ ...finding, id: "F-001", collectedAt: now }] },
    evidence: [{ module: "TLS & headers", status: "ok", classification: "VERIFIED" }] };
  SL.decorateFindings(u, second);
  assert.equal(second.risk.findings[0].freshness, "RECURRING");
  assert.equal(second.risk.findings[0].firstSeenAt, firstAt);
  assert.equal(second.risk.findings[0].lastSeenAt, now);
  SL.recordInvestigation(u, second);

  const third = { domain: "history.example", generatedAt: new Date(Date.now() + 1000).toISOString(), investigationId: "INV-THIRD",
    risk: { findings: [] }, evidence: [{ module: "TLS & headers", status: "failed (timed out)", classification: "SOURCE UNAVAILABLE" }] };
  SL.decorateFindings(u, third);
  assert.equal(third.unobservedFindings.length, 1);
  assert.equal(third.unobservedFindings[0].freshness, "UNAVAILABLE");
  assert.equal(third.unobservedFindings[0].lastSeenAt, now);
  assert.match(third.unobservedFindings[0].note, /not cleared/);
});
