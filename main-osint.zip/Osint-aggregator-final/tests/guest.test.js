// Guest mode, on the offline mock (TEST DATA). Real server, real HTTP; no cookies are sent for the guest.
const test = require("node:test"), assert = require("node:assert"), { spawn } = require("node:child_process"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const start = async (port, env) => { const srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, ".."), env: { ...process.env, PORT: port, DATA_DIR: fs.mkdtempSync(os.tmpdir() + "/gu-"), ...env }, stdio: "ignore" });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(`http://127.0.0.1:${port}/api/health`)).ok) return srv; } catch {} await new Promise((r) => setTimeout(r, 250)); } srv.kill(); throw new Error("server did not start"); };
const mk = (port) => { const B = `http://127.0.0.1:${port}`; return (m, u, body, cookie) => fetch(B + u, { method: m, headers: { "Content-Type": "application/json", Origin: B, ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined }); };
let srv, g; test.before(async () => { srv = await start(5392, {}); g = mk(5392); }); test.after(() => srv && srv.kill());

test("a guest sees a session with a 2-scan limit, and only the public routes", async () => {
  const s = await (await g("GET", "/api/session")).json(); assert.equal(s.guest, true); assert.equal(s.rate.limit, 2); assert.equal(s.rate.remaining, 2);
  for (const u of ["/api/reports", "/api/reports/1", "/api/dashboard", "/api/engines", "/api/engine-registry", "/api/audit", "/api/sources", "/api/findings", "/api/auth/me", "/api/limit"]) assert.equal((await g("GET", u)).status, 401, u);
  for (const [m, u] of [["DELETE", "/api/reports/1"], ["POST", "/api/account/password"], ["POST", "/api/account/delete"], ["POST", "/api/account/profile"]]) assert.equal((await g(m, u, {})).status, 401, u);
  assert.equal((await fetch("http://127.0.0.1:5392/scan")).status, 200);
});
test("guest scans: consent and SSRF rules still apply, results are not saved, the quota is enforced, cache hits are free", async () => {
  assert.equal((await g("POST", "/api/recon", { domain: "example.com" })).status, 400);
  for (const t of ["localhost", "127.0.0.1", "169.254.169.254", "x.localdomain"]) assert.equal((await g("POST", "/api/recon", { domain: t, consent: true })).status, 400, t);
  const a = await (await g("POST", "/api/recon", { domain: "example.com", consent: true })).json(); assert.equal(a.saved, false); assert.ok(a.risk && a.evidence.length); assert.equal(a.rate.limit, 2); assert.equal(a.rate.remaining, 1);
  assert.equal((await g("POST", "/api/recon", { domain: "example.org", consent: true })).status, 200);
  const blocked = await g("POST", "/api/recon", { domain: "example.net", consent: true }); assert.equal(blocked.status, 429); assert.equal((await blocked.json()).limit, 2);
  assert.equal((await g("POST", "/api/recon", { domain: "example.com", consent: true })).status, 200, "a cached report costs no quota");
  assert.equal((await g("POST", "/api/ipscan", { ip: "93.184.216.34", consent: true })).status, 429, "IP lookups share the guest quota");
  globalThis.__guestReport = a;
});
test("a guest can export the current result, and nothing from guests reaches any account", async () => {
  for (const f of ["pdf", "docx"]) { const r = await g("POST", "/api/export/" + f, { report: globalThis.__guestReport }); assert.equal(r.status, 200); const b = Buffer.from(await r.arrayBuffer()); assert.ok(b.slice(0, 4).toString("latin1").startsWith(f === "pdf" ? "%PDF" : "PK")); }
  const reg = await g("POST", "/api/auth/register", { email: "u@t.com", password: "password-1234", name: "U" }); const ck = reg.headers.getSetCookie().map((x) => x.split(";")[0]).join("; ");
  assert.equal((await (await g("GET", "/api/reports", null, ck)).json()).reports.length, 0, "no guest report is stored anywhere");
  const d = await (await g("GET", "/api/dashboard", null, ck)).json(); assert.deepEqual([d.total, d.reports], [0, 0]);
});
test("ALLOW_GUEST=0 closes guest access completely", async () => {
  const s2 = await start(5393, { ALLOW_GUEST: "0" }); try { const h = mk(5393); assert.equal((await (await h("GET", "/api/session")).json()).guest, false);
    assert.equal((await h("POST", "/api/recon", { domain: "example.com", consent: true })).status, 401); assert.equal((await h("POST", "/api/export/pdf", { report: {} })).status, 401);
    assert.equal((await fetch("http://127.0.0.1:5393/scan", { redirect: "manual" })).status, 302); } finally { s2.kill(); }
});
test("GUEST_EXPORT=0 disables guest exports only", async () => {
  const s3 = await start(5394, { GUEST_EXPORT: "0" }); try { const h = mk(5394); assert.equal((await h("POST", "/api/export/pdf", { report: { domain: "example.com" } })).status, 403); assert.equal((await h("POST", "/api/recon", { domain: "localhost", consent: true })).status, 400); } finally { s3.kill(); }
});
test("guest concurrency cap rejects excess simultaneous scans without consuming them", async () => {
  const s4 = await start(5395, { GUEST_MAX_CONCURRENT: "1", GUEST_RATE_LIMIT: "5", MOCK_SLOW_MS: "5" });
  try {
    const h = mk(5395);
    const responses = await Promise.all(Array.from({ length: 6 }, () => h("POST", "/api/recon", { domain: "example.com", consent: true })));
    const statuses = responses.map((r) => r.status);
    assert.equal(statuses.filter((s) => s === 200).length, 1);
    assert.equal(statuses.filter((s) => s === 503).length, 5);
    const session = await (await h("GET", "/api/session")).json();
    assert.equal(session.rate.remaining, session.rate.limit - 1, "only the accepted scan uses quota");
  } finally { s4.kill(); }
});
