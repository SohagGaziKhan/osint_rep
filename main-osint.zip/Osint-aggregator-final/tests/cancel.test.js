// Cancel + re-run on a SLOW offline mock (TEST DATA). Real server, real HTTP, the client really disconnects mid-scan.
const test = require("node:test"), assert = require("node:assert"), { spawn } = require("node:child_process"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const PORT = 5395, B = `http://127.0.0.1:${PORT}`; let srv, cookie = "";
const call = (m, u, body, o = {}) => fetch(B + u, { method: m, headers: { "Content-Type": "application/json", Origin: B, Cookie: cookie }, body: body ? JSON.stringify(body) : undefined, ...o });
test.before(async () => { srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, ".."), env: { ...process.env, PORT, MOCK_SLOW_MS: "700", DATA_DIR: fs.mkdtempSync(os.tmpdir() + "/cx-") }, stdio: "ignore" });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(B + "/api/health")).ok) break; } catch {} await new Promise((r) => setTimeout(r, 250)); }
  const r = await call("POST", "/api/auth/register", { email: "c@t.com", password: "password-1234", name: "C" }); cookie = r.headers.getSetCookie().map((x) => x.split(";")[0]).join("; "); });
test.after(() => srv && srv.kill());
test("cancelling mid-scan discards the result, saves nothing, keeps the quota spent and counts it as cancelled", async () => {
  const ctl = new AbortController(); const res = await call("POST", "/api/recon/stream", { domain: "example.com", consent: true }, { signal: ctl.signal });
  const rd = res.body.getReader(); await rd.read(); ctl.abort(); try { await rd.cancel(); } catch {} // first progress line received, then the client goes away
  await new Promise((r) => setTimeout(r, 3500));
  const d = await (await call("GET", "/api/dashboard")).json(); assert.equal(d.cancelled, 1); assert.equal(d.completed, 0);
  assert.equal((await (await call("GET", "/api/reports")).json()).reports.length, 0, "a cancelled scan is not saved");
  assert.equal((await (await call("GET", "/api/limit")).json()).remaining, 2, "the quota is not refunded on cancel");
});
test("refresh:true ignores the cache and runs a fresh scan; without it the cached report is served", async () => {
  const first = await (await call("POST", "/api/recon", { domain: "example.com", consent: true })).json(); assert.equal(first.cached, false);
  const again = await (await call("POST", "/api/recon", { domain: "example.com", consent: true })).json(); assert.equal(again.cached, true);
  const fresh = await (await call("POST", "/api/recon", { domain: "example.com", consent: true, refresh: true })).json(); assert.equal(fresh.cached, false); assert.notEqual(fresh.investigationId, first.investigationId);
});
