// Optional browser smoke test (needs `npm i -D playwright` and `npx playwright install chromium`). Run: node tests/browser/smoke.js
// Starts the real server on an OFFLINE MOCK with a malicious page title, then checks tabs, XSS and horizontal overflow.
const { spawn } = require("child_process"), path = require("path"), os = require("os"), fs = require("fs"), { chromium } = require("playwright");
const PORT = 5471, B = `http://127.0.0.1:${PORT}`, TABS = ["domain", "sub", "mail", "social", "hist", "search", "graph", "gdork", "threat", "reports"];
const srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, "../.."), env: { ...process.env, PORT, MOCK_EVIL: "1", DATA_DIR: fs.mkdtempSync(os.tmpdir() + "/br-") }, stdio: "ignore" });
const fail = (m) => { console.error("FAIL:", m); srv.kill(); process.exit(1); };
(async () => {
  for (let i = 0; i < 40; i++) { try { if ((await fetch(B + "/api/health")).ok) break; } catch {} await new Promise((r) => setTimeout(r, 250)); }
  const br = await chromium.launch(); const errs = [];
  for (const w of [320, 768, 1440]) {
    const ctx = await br.newContext({ viewport: { width: w, height: 800 }, isMobile: w < 768 }), pg = await ctx.newPage(); pg.on("pageerror", (e) => errs.push(String(e)));
    const ov = () => pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth");
    await pg.goto(B + "/login"); if (w === 320) { // first context registers and scans
      const H = { "Content-Type": "application/json", Origin: B }; const r = await fetch(B + "/api/auth/register", { method: "POST", headers: H, body: JSON.stringify({ email: "s@t.com", password: "password-1234", name: "S" }) });
      const ck = r.headers.getSetCookie().map((x) => x.split(";")[0]).join("; "); await fetch(B + "/api/recon", { method: "POST", headers: { ...H, Cookie: ck }, body: JSON.stringify({ domain: "example.com", consent: true }) }); }
    await pg.fill("input[type=email]", "s@t.com"); await pg.fill("input[type=password]", "password-1234"); await pg.click('button:has-text("Log in") >> nth=-1'); await pg.waitForTimeout(900);
    const go = async (v) => { if (w < 900 && !(await pg.evaluate("document.getElementById('sidebar').classList.contains('open')"))) await pg.click("#menuBtn"); if (v === "workspace") { await pg.click("#scGroup"); await pg.waitForTimeout(250);
      if (w < 900 && !(await pg.evaluate("document.getElementById('sidebar').classList.contains('open')"))) fail("the mobile drawer closed when the Scan Center group was tapped");
      if (!(await pg.isVisible("[data-sc=domain]"))) fail("Scan Center list not visible"); const bx = await pg.locator("[data-sc=domain]").boundingBox(); if (!bx || bx.x < 0) fail("Scan Center items are off screen");
      await pg.click("[data-sc=domain]"); } else await pg.click(`[data-view=${v}]`); await pg.waitForTimeout(400); };
    await go("workspace"); let max = 0; for (const t of TABS) { await pg.click(`[data-t=${t}]`); await pg.waitForTimeout(100); if (!(await pg.innerText("#wsBody")).trim()) fail("empty tab " + t); max = Math.max(max, await ov()); }
    if (max > 0) fail(`overflow ${max}px at ${w}px`); if (await pg.evaluate("window.__xss")) fail("XSS executed"); await ctx.close();
  }
  await br.close(); srv.kill(); if (errs.length) { console.error("page errors:", errs); process.exit(1); } console.log("browser smoke: PASS (10 tabs x 3 widths, no overflow, no XSS, no page errors)");
})().catch((e) => fail(e.stack));
