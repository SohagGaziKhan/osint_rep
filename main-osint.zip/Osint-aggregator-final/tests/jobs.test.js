// Background jobs: real server, real HTTP, slow offline mock (TEST DATA).
const test = require("node:test"), assert = require("node:assert"), { spawn } = require("node:child_process"), path = require("node:path"), fs = require("node:fs"), os = require("node:os");
const start = async (port, dir, env = {}) => { const srv = spawn(process.execPath, ["-r", "./tests/helpers/netmock.js", "server.js"], { cwd: path.join(__dirname, ".."), env: { ...process.env, PORT: port, DATA_DIR: dir, RATE_LIMIT: "30", JOB_CONCURRENCY: "1", MOCK_SLOW_MS: "300", ...env }, stdio: "ignore" });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(`http://127.0.0.1:${port}/api/health`)).ok) return srv; } catch {} await new Promise((r) => setTimeout(r, 250)); } srv.kill(); throw new Error("server did not start"); };
const mk = (port) => { const B = `http://127.0.0.1:${port}`, jar = {}; const call = (who, m, u, body) => fetch(B + u, { method: m, headers: { "Content-Type": "application/json", Origin: B, Cookie: jar[who] || "" }, body: body && m !== "GET" ? JSON.stringify(body) : undefined });
  const reg = async (who) => { const r = await call(who, "POST", "/api/auth/register", { email: who + "@t.com", password: "password-1234", name: who }); jar[who] = r.headers.getSetCookie().map((x) => x.split(";")[0]).join("; "); };
  const job = async (who, id) => (await (await call(who, "GET", "/api/jobs/" + id)).json()).job, rem = async (who) => (await (await call(who, "GET", "/api/limit")).json()).remaining;
  const until = async (fn, ms = 40000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await new Promise((r) => setTimeout(r, 250)); } throw new Error("timed out waiting"); };
  return { call, reg, job, rem, until, jar }; };
const dir = fs.mkdtempSync(os.tmpdir() + "/jb-"); let srv, h; test.before(async () => { srv = await start(5397, dir); h = mk(5397); await h.reg("a"); }); test.after(() => srv && srv.kill());

test("jobs queue in order, run without the browser, and save normal reports", async () => {
  const r1 = await h.call("a", "POST", "/api/jobs", { domain: "example.com", consent: true }), j1 = (await r1.json()).job; assert.equal(r1.status, 202);
  const j2 = (await (await h.call("a", "POST", "/api/jobs", { domain: "example.org", consent: true })).json()).job; assert.equal(j2.status, "queued"); assert.equal(j2.queuePosition, 1, "one worker: the second job waits");
  const d1 = await h.until(async () => { const j = await h.job("a", j1.id); return j.status === "completed" && j; }), d2 = await h.until(async () => { const j = await h.job("a", j2.id); return j.status === "completed" && j; });
  assert.ok(d1.finishedAt <= d2.finishedAt, "first in, first out"); assert.ok(d1.done >= 18 && d1.reportId && d1.investigationId);
  for (const [j, dom] of [[d1, "example.com"], [d2, "example.org"]]) { const rep = await (await h.call("a", "GET", "/api/reports/" + j.reportId)).json(); assert.equal(rep.domain, dom); assert.equal(rep.investigationId, j.investigationId); }
  assert.equal((await (await h.call("a", "GET", "/api/jobs")).json()).jobs.length, 2);
});
test("cancel: a waiting job gets its quota back; a running job's result is discarded and its quota stays spent", async () => {
  const r0 = await h.rem("a"); const jA = (await (await h.call("a", "POST", "/api/jobs", { domain: "example.net", consent: true })).json()).job, jB = (await (await h.call("a", "POST", "/api/jobs", { domain: "example.edu", consent: true })).json()).job;
  assert.equal(await h.rem("a"), r0 - 2); const cb = await (await h.call("a", "POST", `/api/jobs/${jB.id}/cancel`)).json(); assert.equal(cb.job.status, "cancelled"); assert.equal(cb.refunded, true); assert.equal(await h.rem("a"), r0 - 1, "refunded: nothing had run");
  await h.until(async () => (await h.job("a", jA.id)).status === "running"); const ca = await (await h.call("a", "POST", `/api/jobs/${jA.id}/cancel`)).json(); assert.equal(ca.job.status, "cancelled"); assert.equal(ca.refunded, false);
  await new Promise((r) => setTimeout(r, 3500)); assert.equal((await h.job("a", jA.id)).status, "cancelled", "a late finish must not overwrite the cancellation");
  const doms = (await (await h.call("a", "GET", "/api/reports")).json()).reports.map((x) => x.domain); assert.ok(!doms.includes("example.net") && !doms.includes("example.edu"), "cancelled work is not saved"); assert.equal(await h.rem("a"), r0 - 1);
  assert.ok((await (await h.call("a", "GET", "/api/dashboard")).json()).cancelled >= 1); assert.equal((await (await h.call("a", "POST", `/api/jobs/${jA.id}/cancel`)).json()).already, true);
});
test("ownership, guests, validation that costs no quota, and the per-user active limit", async () => {
  await h.reg("b"); const jid = (await (await h.call("a", "GET", "/api/jobs")).json()).jobs[0].id;
  assert.equal((await h.call("b", "GET", "/api/jobs/" + jid)).status, 404); assert.equal((await h.call("b", "POST", `/api/jobs/${jid}/cancel`)).status, 404); assert.deepEqual((await (await h.call("b", "GET", "/api/jobs")).json()).jobs, []);
  for (const [m, u] of [["POST", "/api/jobs"], ["GET", "/api/jobs"], ["GET", "/api/jobs/" + jid], ["POST", `/api/jobs/${jid}/cancel`]]) assert.equal((await h.call("nobody", m, u, { domain: "example.com", consent: true })).status, 401, u);
  assert.equal((await h.call("a", "GET", "/api/jobs/not-an-id")).status, 404); assert.equal((await h.call("a", "GET", "/api/jobs/..%2F..%2Fetc")).status, 404);
  const q0 = await h.rem("b"); assert.equal((await h.call("b", "POST", "/api/jobs", { domain: "example.com" })).status, 400, "consent required"); for (const d of ["localhost", "127.0.0.1", "x.localdomain", "169.254.169.254"]) assert.equal((await h.call("b", "POST", "/api/jobs", { domain: d, consent: true })).status, 400, d);
  assert.equal(await h.rem("b"), q0, "rejected names cost no quota");
  await h.reg("c"); const c0 = await h.rem("c"); for (const d of ["a1.example.com", "a2.example.com", "a3.example.com"]) assert.equal((await h.call("c", "POST", "/api/jobs", { domain: d, consent: true })).status, 202);
  const over = await h.call("c", "POST", "/api/jobs", { domain: "a4.example.com", consent: true }); assert.equal(over.status, 429); assert.equal(await h.rem("c"), c0 - 3, "the refused job was refunded");
});
test("a server restart marks waiting and running jobs interrupted instead of losing track of them", async () => {
  const d2 = fs.mkdtempSync(os.tmpdir() + "/jr-"); let s1 = await start(5399, d2, { MOCK_SLOW_MS: "4000" }); const h1 = mk(5399); await h1.reg("r");
  const run = (await (await h1.call("r", "POST", "/api/jobs", { domain: "example.com", consent: true })).json()).job, wait = (await (await h1.call("r", "POST", "/api/jobs", { domain: "example.org", consent: true })).json()).job;
  await h1.until(async () => (await h1.job("r", run.id)).status === "running"); const cookie = h1.jar.r; s1.kill("SIGKILL"); await new Promise((r) => setTimeout(r, 800));
  const s2 = await start(5399, d2, {}); try { const B = "http://127.0.0.1:5399", get = async (id) => (await (await fetch(B + "/api/jobs/" + id, { headers: { Cookie: cookie } })).json()).job;
    for (const j of [run, wait]) { const x = await get(j.id); assert.equal(x.status, "interrupted", j.id); assert.match(x.error, /restarted/); }
    const fresh = await fetch(B + "/api/jobs", { method: "POST", headers: { "Content-Type": "application/json", Origin: B, Cookie: cookie }, body: JSON.stringify({ domain: "example.com", consent: true, refresh: true }) }); assert.equal(fresh.status, 202, "new jobs work after a restart"); } finally { s2.kill(); }
});
