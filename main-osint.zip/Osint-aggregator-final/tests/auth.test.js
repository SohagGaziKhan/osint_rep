process.env.DATA_DIR = require("fs").mkdtempSync(require("path").join(require("os").tmpdir(), "softinza-auth-"));
const test = require("node:test"), assert = require("node:assert");
const A = require("../lib/auth");
let n = 0;
const reg = (e, p = "correct horse 9", ip = "10.0.0." + ++n) => A.register({ email: e, password: p, name: " Test ", ip });
const rejects = (p, status) => assert.rejects(p, (e) => e instanceof A.AuthError && e.status === status);

test("password hashing: verifies right password, rejects wrong, never stores plaintext", async () => {
  const h = await A.hashPassword("secret-pass-1"); assert.ok(h.startsWith("scrypt$") && !h.includes("secret-pass-1"));
  assert.ok(await A.verifyPassword("secret-pass-1", h)); assert.ok(!(await A.verifyPassword("wrong", h))); assert.ok(!(await A.verifyPassword("x", "garbage")));
});
test("register validates email and password, blocks duplicates", async () => {
  await rejects(reg("not-an-email"), 400); await rejects(reg("a@b.co", "short"), 400);
  await reg("Dup@Example.com"); await rejects(reg("dup@example.com"), 409);
});
test("login, session and logout", async () => {
  const id = await reg("login@example.com"); assert.strictEqual(await A.login({ email: "LOGIN@example.com", password: "correct horse 9", ip: "2.2.2.2" }), id);
  const t = A.createSession(id), u = A.userFromToken(t); assert.strictEqual(u.email, "login@example.com"); assert.strictEqual(u.name, "Test");
  A.destroySession(t); assert.strictEqual(A.userFromToken(t), null); assert.strictEqual(A.userFromToken("forged"), null);
});
test("wrong password and unknown email give the same message; repeated failures are throttled", async () => {
  await reg("thr@example.com");
  const msg = async (e, p) => { try { await A.login({ email: e, password: p, ip: "3.3.3.3" }); } catch (x) { return x.message + x.status; } };
  assert.strictEqual(await msg("thr@example.com", "bad-pass-1"), await msg("nobody@example.com", "bad-pass-1"));
  for (let i = 0; i < 8; i++) await msg("thr@example.com", "bad-pass-" + i);
  await rejects(A.login({ email: "thr@example.com", password: "correct horse 9", ip: "3.3.3.3" }), 429);
});
test("password change signs out other sessions; delete account cascades", async () => {
  const id = await reg("chg@example.com"), keep = A.createSession(id), other = A.createSession(id);
  await rejects(A.changePassword(id, "nope", "new-password-1", keep), 401);
  await A.changePassword(id, "correct horse 9", "new-password-1", keep);
  assert.ok(A.userFromToken(keep)); assert.strictEqual(A.userFromToken(other), null);
  A.saveReport(id, { domain: "x.com", risk: { level: "Low" } });
  await rejects(A.deleteAccount(id, "wrong"), 401); await A.deleteAccount(id, "new-password-1");
  assert.strictEqual(A.userFromToken(keep), null); assert.deepStrictEqual(A.listReports(id), []);
});
test("reports: round trip, per-user isolation, 30-report cap, delete", async () => {
  const a = await reg("ra@example.com"), b = await reg("rb@example.com");
  const rid = A.saveReport(a, { domain: "one.com", risk: { level: "High" }, big: "x".repeat(5000) });
  assert.strictEqual(A.getReport(a, rid).domain, "one.com"); assert.strictEqual(A.getReport(b, rid), null);
  assert.strictEqual(A.deleteReport(b, rid), false); assert.strictEqual(A.deleteReport(a, rid), true);
  for (let i = 0; i < 35; i++) A.saveReport(a, { domain: `d${i}.com` });
  const l = A.listReports(a); assert.strictEqual(l.length, 30); assert.strictEqual(l[0].domain, "d34.com");
});
test("sign-ups can be closed", async () => {
  process.env.ALLOW_SIGNUP = "0"; await rejects(reg("closed@example.com"), 403); delete process.env.ALLOW_SIGNUP;
});
