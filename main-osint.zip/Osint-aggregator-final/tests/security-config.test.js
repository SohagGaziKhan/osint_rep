const test = require("node:test");
const assert = require("node:assert");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const root = path.join(__dirname, "..");
async function start(port, extra = {}) {
  const server = spawn(process.execPath, ["server.js"], { cwd: root, env: {
    ...process.env, PORT: String(port), HOST: "127.0.0.1",
    DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), "softinza-cookie-")),
    ALLOW_GUEST: "0", ...extra,
  }, stdio: "ignore" });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 40; i++) {
    try { if ((await fetch(base + "/api/health")).ok) return { server, base }; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  server.kill();
  throw new Error("server did not start");
}

async function register(base, email, forwardedProto) {
  const headers = { "Content-Type": "application/json", Origin: base };
  if (forwardedProto) headers["X-Forwarded-Proto"] = forwardedProto;
  const response = await fetch(base + "/api/auth/register", {
    method: "POST",
    headers,
    body: JSON.stringify({ email, password: "secure-password-123" }),
  });
  assert.equal(response.status, 200);
  return response.headers.getSetCookie()[0];
}

test("Secure cookies honor trusted HTTPS proxy headers and COOKIE_SECURE", async () => {
  const proxy = await start(5396, { TRUST_PROXY: "1", COOKIE_SECURE: "0" });
  try {
    const forwarded = await register(proxy.base, "proxy@example.test", "https");
    assert.match(forwarded, /;\s*Secure(?:;|$)/i);
    assert.match(forwarded, /HttpOnly/i);
    assert.match(forwarded, /SameSite=Lax/i);
    const plain = await register(proxy.base, "plain@example.test");
    assert.doesNotMatch(plain, /;\s*Secure(?:;|$)/i);
  } finally { proxy.server.kill(); }

  const forced = await start(5397, { COOKIE_SECURE: "1" });
  try {
    const cookie = await register(forced.base, "forced@example.test");
    assert.match(cookie, /;\s*Secure(?:;|$)/i);
  } finally { forced.server.kill(); }
});
