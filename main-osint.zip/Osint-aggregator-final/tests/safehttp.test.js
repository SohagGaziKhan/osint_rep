// REAL network stack on loopback only (no netmock): the guard must stop internal targets, DNS answers and redirects.
const test = require("node:test"), assert = require("node:assert"), http = require("node:http"), axios = require("axios");
const R = require("../lib/recon"), G = require("../lib/safeHttp");
test("reserved/internal suffixes are rejected before any network call", async () => {
  for (const d of ["localhost.localdomain", "x.intranet", "a.home.arpa", "svc.private", "a.test", "x.invalid", "db.internal", "printer.lan"]) await assert.rejects(R.runRecon(d), R.ReconError, d);
});
test("guarded axios refuses a name that resolves to loopback (connection-time check)", async () => {
  const srv = http.createServer((q, s) => s.end("secret")).listen(0, "127.0.0.1"); await new Promise((r) => srv.once("listening", r));
  try { await assert.rejects(axios.get(`http://localhost:${srv.address().port}/`, { timeout: 3000 }), /Blocked|EBLOCKED/); } finally { srv.close(); }
});
test("redirects to internal IP literals are aborted; public hosts pass", () => {
  for (const h of ["169.254.169.254", "127.0.0.1", "10.0.0.5", "192.168.1.1", "[::1]", "0.0.0.0", ""]) assert.throws(() => G.beforeRedirect({ hostname: h }), /Blocked/, h);
  assert.doesNotThrow(() => G.beforeRedirect({ hostname: "example.com" })); assert.doesNotThrow(() => G.beforeRedirect({ hostname: "93.184.216.34" }));
});
test("guard is installed on axios defaults", () => { assert.ok(axios.defaults.httpAgent && axios.defaults.httpsAgent && axios.defaults.beforeRedirect); });
