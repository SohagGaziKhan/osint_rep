process.env.DATA_DIR = require("node:fs").mkdtempSync(require("node:path").join(require("node:os").tmpdir(), "softinza-tx-"));
const test = require("node:test");
const assert = require("node:assert");
const db = require("../lib/db");
const transaction = require("../lib/dbTransaction");

test("SQLite transaction rolls back failed grouped writes", () => {
  db.exec("CREATE TABLE tx_probe (value TEXT NOT NULL)");
  assert.throws(() => transaction(() => {
    db.prepare("INSERT INTO tx_probe (value) VALUES (?)").run("first");
    db.prepare("INSERT INTO tx_probe (value) VALUES (?)").run(null);
  }));
  assert.equal(db.prepare("SELECT COUNT(*) n FROM tx_probe").get().n, 0);
});

test("SQLite transaction rejects asynchronous callbacks and rolls back", async () => {
  db.exec("CREATE TABLE tx_async_probe (value TEXT NOT NULL)");
  assert.throws(() => transaction(async () => {
    db.prepare("INSERT INTO tx_async_probe (value) VALUES (?)").run("first");
  }), /must be synchronous/);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM tx_async_probe").get().n, 0);
});
