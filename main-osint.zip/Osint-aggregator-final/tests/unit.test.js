process.env.RATE_LIMIT = "2";
process.env.DATA_DIR = require("fs").mkdtempSync(require("path").join(require("os").tmpdir(), "softinza-"));
const test = require("node:test"), assert = require("node:assert"), fs = require("fs"), path = require("path");
const { normalizeDomain, isPrivateIp, runRecon, ReconError } = require("../lib/recon");
const { variants } = require("../lib/typosquatModule");
const { platformOf } = require("../lib/profileModule");
const { summarize } = require("../lib/riskModule");
const { diffAndSave } = require("../lib/historyModule");
const L = require("../lib/limiter");
const { generateDorks } = require("../lib/dorkModule");
const E = require("../lib/enrichModule");
const { buildModel } = require("../lib/reportModel");
const { toDocx, toPdf } = require("../lib/reportExport");
const { parseWhoisFields } = require("../lib/whoisModule");

test("normalizeDomain strips scheme, port, path, case", () => assert.strictEqual(normalizeDomain(" HTTPS://Example.com:8080/x?y#z "), "example.com"));
test("isPrivateIp flags internal ranges only", () => {
  for (const ip of ["127.0.0.1", "10.1.1.1", "192.168.0.1", "172.16.0.1", "169.254.1.1", "100.64.0.1", "::1", "fd00::1"]) assert.ok(isPrivateIp(ip), ip);
  for (const ip of ["8.8.8.8", "1.1.1.1", "172.32.0.1"]) assert.ok(!isPrivateIp(ip), ip);
});
test("runRecon rejects invalid or internal targets before any network call", async () => {
  for (const d of ["", "localhost", "192.168.1.1", "foo.local", "not a domain"]) await assert.rejects(runRecon(d), ReconError, d);
});
test("typosquat variants: swap and homoglyph, never the original", () => {
  const v = variants("example.com");
  assert.ok(v.includes("exmaple.com") && v.includes("examp1e.com") && !v.includes("example.com"));
  assert.ok(v.every((x) => /^[a-z0-9]([a-z0-9-]*[a-z0-9])?\.[a-z.]+$/.test(x)));
});
test("platformOf accepts profiles and rejects share/intent/repo links", () => {
  const p = (u) => platformOf(new URL(u));
  assert.strictEqual(p("https://www.facebook.com/acme"), "facebook"); assert.strictEqual(p("https://facebook.com/sharer/sharer.php"), null);
  assert.strictEqual(p("https://www.linkedin.com/company/acme"), "linkedin"); assert.strictEqual(p("https://www.linkedin.com/in/someone"), null);
  assert.strictEqual(p("https://twitter.com/intent/tweet"), null); assert.strictEqual(p("https://github.com/acme"), "github"); assert.strictEqual(p("https://github.com/acme/repo"), null);
  assert.strictEqual(p("https://youtube.com/@acme"), "youtube");
});
test("summarize ranks findings and sets level", () => {
  const r = summarize({ ssl: { daysLeft: -1, trusted: true }, emailAuth: { spf: null, dmarc: null }, ipIntel: [{ ip: "1.1.1.1", ports: [3389], vulns: [] }] }, []);
  assert.strictEqual(r.level, "High"); assert.strictEqual(r.findings[0].sev, "high"); assert.ok(r.findings.some((f) => /No SPF/.test(f.msg)));
});
test("diffAndSave: first scan, then added/removed", () => {
  const dom = "unit-test-domain.example", f = path.join(process.env.DATA_DIR, dom + ".json");
  try { fs.rmSync(f, { force: true }); } catch {}
  const base = { at: "t", subdomains: ["a"], ports: [], vulns: [] };
  assert.strictEqual(diffAndSave(dom, base).first, true);
  const d = diffAndSave(dom, { ...base, subdomains: ["b"] });
  assert.deepStrictEqual([d.subdomains.added, d.subdomains.removed], [["b"], ["a"]]);
  fs.rmSync(f, { force: true });
});
test("limiter: quota, refund, cache", () => {
  L.consume("ip"); L.consume("ip"); assert.strictEqual(L.status("ip").remaining, 0);
  L.refund("ip"); assert.strictEqual(L.status("ip").remaining, 1);
  assert.strictEqual(L.getCached("x.com"), null); L.setCached("x.com", { a: 1 }); assert.deepStrictEqual(L.getCached("x.com").report, { a: 1 });
});
test("dorks: scoped to domain, categorised, no person-targeting", () => {
  const g = generateDorks("acme.com");
  assert.ok(g.length > 30 && g.some((x) => x.query === "site:acme.com") && g.some((x) => x.cat === "Reviews & ratings"));
  assert.ok(g.every((x) => x.url.startsWith("https://")) && !g.some((x) => x.query.includes("linkedin.com/in")));
});
test("enrich: classify, timeline order, graph root", () => {
  assert.deepStrictEqual(E.classify({ MX: [{ exchange: "aspmx.l.google.com" }] }, []).mailProviders, ["Google Workspace"]);
  const t = E.timeline({ rdap: { created: "2020-01-01", expires: "2030-01-01" }, changes: { first: true } }); assert.ok(t[0].date < t[1].date);
  const g = E.graph({ domain: "a.com", dns: { NS: ["ns1.x.com"] }, ipIntel: [], subdomainStatus: [], infra: {} });
  assert.strictEqual(g.nodes[0].id, "a.com"); assert.strictEqual(g.edges.length, 1);
});
test("WHOIS parser keeps technical registration fields and excludes registrant contact details", () => {
  const parsed = parseWhoisFields([
    "Registry Domain ID: D123-EXAMPLE",
    "Registrar WHOIS Server: whois.example.test",
    "Registrar URL: https://registrar.example.test",
    "Updated Date: 2026-11-01T10:00:00Z",
    "Creation Date: 2018-08-09T00:00:00Z",
    "Registry Expiry Date: 2029-08-09T00:00:00Z",
    "Registrar: Example Registrar",
    "Registrar IANA ID: 82",
    "Domain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited",
    "Name Server: NS1.EXAMPLE.TEST",
    "Registrant Name: Private Person",
    "Registrant Email: person@example.test",
    "Registrant Phone: +1.5550100",
    "Registrant Street: 1 Example Street",
  ].join("\n"));
  assert.equal(parsed.registryDomainId, "D123-EXAMPLE");
  assert.equal(parsed.registrarIanaId, "82");
  assert.equal(parsed.creationDate, "2018-08-09T00:00:00Z");
  assert.equal(parsed.updatedDate, "2026-11-01T10:00:00Z");
  assert.deepEqual(parsed.nameServers, ["ns1.example.test"]);
  assert.match(parsed.status[0], /clientTransferProhibited/);
  assert.doesNotMatch(JSON.stringify(parsed), /Private Person|person@example\.test|5550100|Example Street/);
});
test("buildModel survives an almost-empty report", () => {
  const m = buildModel({ domain: "x.com", generatedAt: "t" }); assert.strictEqual(m.sections.length, 22); assert.strictEqual(m.sections[0].title, "Executive Summary");
});
test("buildModel preserves WHOIS, DNS, subdomain provenance and company profile details", () => {
  const m = buildModel({
    domain: "example.com",
    whois: { registrar: "Example Registrar", creationDate: "2020-01-01", rawAvailable: true, nameServers: ["ns1.example.com"] },
    rdap: { registrar: "Example Registrar", registryDomainId: "REG-123", registrarIanaId: "82", registrarWhoisServer: "whois.example.com", expires: "2030-01-01", nameServers: ["ns1.example.com"], status: ["active"], dnssec: true },
    dns: { A: ["192.0.2.2"], MX: [{ exchange: "mail.example.com", priority: 10 }], SOA: [{ nsname: "ns1.example.com" }] },
    subdomainStatus: [{ name: "app.example.com", live: false, ips: [], ipv6: ["2001:db8::1"], cname: "old.hosting.example", sources: ["crt.sh"], takeover: "possible dangling CNAME" }],
    subdomainDiscoveredCount: 151, subdomainCheckedCount: 150, subdomainProviders: { "crt.sh": "fulfilled", Anubis: "rejected" },
    profile: {
      source: "https://example.com", fetchedAt: "2026-01-01T00:00:00.000Z",
      company: { name: "Example Org", emails: ["hello@example.com"], phones: ["+1 555 0100"] },
      metadata: { schemaTypes: ["Organization"], lang: "en" }, pages: { about: ["https://example.com/about"] }, social: [],
    },
    evidence: [], risk: { findings: [] },
  });
  const section = (prefix) => m.sections.find((s) => s.title.includes(prefix));
  const domain = section("Domain & DNS Intelligence");
  assert.ok(domain.rows.some(([key, value]) => key === "Created" && value === "2020-01-01"));
  assert.ok(domain.rows.some(([key, value]) => key === "Registry domain ID" && value === "REG-123"));
  assert.ok(domain.rows.some(([key, value]) => key === "SOA" && value.includes("nsname: ns1.example.com")));
  const subs = section("Subdomain & Certificate Discovery");
  assert.ok(subs.rows.some(([key, value]) => key === "Subdomains found" && value === 151));
  assert.ok(subs.rows.some(([key, value]) => key === "Source: Anubis" && value === "rejected"));
  assert.ok(subs.bullets.some((text) => text.includes("app.example.com") && text.includes("crt.sh") && text.includes("old.hosting.example")));
  assert.ok(subs.bullets.some((text) => text.includes("IPv6: 2001:db8::1")));
  const company = section("Company & Brand Intelligence");
  assert.ok(company.rows.some(([key, value]) => key === "Published emails" && value === "hello@example.com"));
  assert.ok(company.rows.some(([key, value]) => key === "Company pages" && value.includes("/about")));
});
test("Word and PDF exports produce valid files", async () => {
  const m = buildModel({ domain: "x.com", generatedAt: "t", risk: { level: "Low", findings: [] } });
  assert.strictEqual((await toDocx(m)).subarray(0, 2).toString(), "PK"); assert.strictEqual((await toPdf(m)).subarray(0, 4).toString(), "%PDF");
});
test("limiter persists quota and cache across a restart; cache has an expiry", () => {
  L.consume("p"); L.setCached("persist.com", { a: 1 }); L.flush();
  delete require.cache[require.resolve("../lib/limiter")];
  const L2 = require("../lib/limiter");
  assert.strictEqual(L2.status("p").remaining, 1);
  const c = L2.getCached("persist.com"); assert.deepStrictEqual(c.report, { a: 1 }); assert.ok(c.expiresAt > Date.now());
});
test("unverified Shodan-style findings cannot make the level High; every finding has provenance", () => {
  const r = summarize({ generatedAt: "t", ipIntel: [{ ip: "1.1.1.1", ports: [3389], vulns: ["CVE-1"] }] }, ["CVE-1"]);
  assert.strictEqual(r.level, "Medium");
  assert.ok(r.findings.every((f) => f.source && f.confidence && f.remediation && f.at && typeof f.verified === "boolean"));
  assert.ok(r.findings.some((f) => f.sev === "high" && f.verified === false));
});

test("IP lookup and company finder reject bad input before any network call", async () => {
  const { ipScan } = require("../lib/lookupModule"), { companyLookup } = require("../lib/companyLookup");
  for (const ip of ["", "not-an-ip", "10.0.0.1", "127.0.0.1", "192.168.1.1", "::1"]) await assert.rejects(ipScan(ip), (e) => e.status === 400, ip);
  await assert.rejects(companyLookup("a"), (e) => e.status === 400);
});
