// SoftInza built-in engine + fallback decision. Offline mock (TEST DATA) and FAKE tool binaries.
require("./helpers/netmock.js");
const test = require("node:test"), assert = require("node:assert"), fs = require("node:fs"), os = require("node:os"), path = require("node:path"), axios = require("axios");
const dir = fs.mkdtempSync(os.tmpdir() + "/fk-"); const mk = (n, b) => fs.writeFileSync(path.join(dir, n), "#!/bin/sh\n" + b, { mode: 0o755 });
mk("theHarvester", 'echo "Google blocked this request: unusual traffic detected, captcha required"\n'); mk("subfinder", "echo good1.example.com\n");
process.env.PATH = dir + path.delimiter + process.env.PATH;
const SE = require("../lib/softinzaEngine"), SM = require("../lib/subdomainModule"), X = require("../lib/externalTools");
const set = (tools, eng) => { process.env.EXTERNAL_TOOLS = tools; process.env.SOFTINZA_ENGINE = eng; };
test("engine keeps only on-target names from every source and reports each source's status", async () => {
  const r = await SE.run("example.com", "t"); assert.equal(r.status, "ok"); assert.equal(r.detail.length, 4);
  for (const n of ["cert1.example.com", "ht1.example.com", "us1.example.com", "wb1.example.com"]) assert.ok(r.names.includes(n), n);
  assert.ok(!r.names.some((n) => n.includes("other.net") || n.includes("elsewhere") || n.includes("*")));
});
test("subdomain discovery rejects suffix lookalikes and normalizes fully qualified names", async () => {
  const orig = axios.get;
  axios.get = async (url, options) => {
    const r = await orig(url, options);
    if (String(url).startsWith("https://crt.sh")) return { ...r, data: [...r.data, { name_value: "notexample.com\napi2.example.com." }] };
    return r;
  };
  try {
    const r = await SM.findSubdomainsDetailed("example.com");
    assert.ok(r.names.includes("api2.example.com"));
    assert.ok(!r.names.includes("notexample.com"));
  } finally { axios.get = orig; }
});
test("subdomain DNS inventory includes AAAA records without flagging healthy CNAMEs", async () => {
  const results = await SM.checkSubdomains(["www.example.com", "old-shop.example.com"]);
  assert.ok(results[0].ipv6.length);
  assert.equal(results[0].resolutionChecked, true);
  assert.ok(results[0].live);
  assert.equal(results[1].live, false);
  assert.ok(results[1].takeover);
});
test("a rate-limited source is reported honestly and the others still deliver", async () => {
  const orig = axios.get; axios.get = async (u, o) => { if (String(u).includes("hackertarget")) { const e = new Error("x"); e.response = { status: 429 }; throw e; } return orig(u, o); };
  try { const r = await SE.run("example.com", "t"); assert.ok(r.detail.includes("HackerTarget: rate limited")); assert.ok(r.names.includes("cert1.example.com")); assert.ok(!r.names.includes("ht1.example.com")); } finally { axios.get = orig; }
});
test("a search-engine block is detected, and the built-in engine takes over (auto)", async () => {
  set("theharvester", "auto"); const d = await SM.findSubdomainsDetailed("example.com");
  assert.ok(d.providers.theHarvester.startsWith("blocked"), d.providers.theHarvester); assert.ok(d.providers["SoftInza Engine"].startsWith("ok"));
  assert.deepEqual(d.sources["cert1.example.com"], ["SoftInza Engine · CertSpotter"]);
  const r = X.takeResults("example.com"); assert.deepEqual(r.tools.map((t) => t.id), ["theharvester", "softinza"]); assert.ok(r.tools[1].reason.includes("blocked") && r.tools[1].detail.length === 4);
});
test("with no tools enabled the engine runs (auto); with a working tool it does not; always/off are honoured", async () => {
  set("", "auto"); assert.ok((await SM.findSubdomainsDetailed("example.com")).providers["SoftInza Engine"]);
  set("subfinder", "auto"); let d = await SM.findSubdomainsDetailed("example.com"); assert.equal(d.providers["SoftInza Engine"], undefined); assert.deepEqual(d.sources["good1.example.com"], ["Subfinder"]);
  set("subfinder", "always"); assert.ok((await SM.findSubdomainsDetailed("example.com")).providers["SoftInza Engine"]);
  set("theharvester", "off"); d = await SM.findSubdomainsDetailed("example.com"); assert.equal(d.providers["SoftInza Engine"], undefined); assert.ok(d.providers.theHarvester.startsWith("blocked"));
});
