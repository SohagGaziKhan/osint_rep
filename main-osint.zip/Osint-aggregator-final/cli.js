// Usage: node cli.js example.com [--docx f.docx] [--pdf f.pdf] [--json f.json]   (no flags: JSON to stdout)
require("./lib/env");
const fs = require("fs");
const { runRecon } = require("./lib/recon");
const { buildModel } = require("./lib/reportModel");
const { toDocx, toPdf } = require("./lib/reportExport");
const [domain, ...flags] = process.argv.slice(2);
const opt = (f) => { const i = flags.indexOf(f); return i >= 0 ? flags[i + 1] : null; };
(async () => {
  try {
    const r = await runRecon(domain), m = buildModel(r);
    if (opt("--docx")) fs.writeFileSync(opt("--docx"), await toDocx(m));
    if (opt("--pdf")) fs.writeFileSync(opt("--pdf"), await toPdf(m));
    if (opt("--json")) fs.writeFileSync(opt("--json"), JSON.stringify(r, null, 2));
    if (!flags.length) console.log(JSON.stringify(r, null, 2));
  } catch (e) { console.error(e.message); process.exit(1); }
})();
