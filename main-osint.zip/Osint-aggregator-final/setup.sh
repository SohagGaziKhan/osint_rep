#!/usr/bin/env bash
# SoftInza OSINT setup (Linux/macOS). Usage: ./setup.sh [--start]
set -e
cd "$(dirname "$0")"
echo "== SoftInza OSINT setup =="
command -v node >/dev/null || { echo "Node.js 20+ is required: https://nodejs.org"; exit 1; }
v=$(node -p "process.versions.node.split('.')[0]")
[ "$v" -ge 20 ] || { echo "Node 20+ required (found $v)"; exit 1; }
npm install
[ -f .env ] || { cp .env.example .env; echo "Created .env (edit it to change limits/port)"; }
npm test || echo "Some tests failed - see output above (the app can still run)."
echo "Verify with real data: npm run selfcheck yourdomain.com"
echo; echo "Setup finished. Start with: npm start  ->  http://localhost:5100"
[ "$1" = "--start" ] && exec npm start || true
