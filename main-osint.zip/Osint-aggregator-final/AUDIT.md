# Audit, source matrix and delivery summary
Statuses: PASS, FAIL, BLOCKED, NOT VERIFIED, NOT APPLICABLE, NOT RUN. A status is PASS only if it was executed and passed here.
Test environment: Linux sandbox, Node 22, **no internet**. Scans ran against an offline mock (TEST DATA) and fake tool binaries.

## 1. Original codebase (prompt 2.1, 19.1)
Node.js + Express (server.js), vanilla-JS single-page UI (views/app.html, login.html), SQLite (`better-sqlite3` with a `node:sqlite` fallback), 18 parallel collectors in lib/recon.js (60 s timeout, one retry each), scrypt password hashing, per-user quota (limiter.json), Word/PDF export (docx, pdf-lib), CLI (cli.js). Original tests: 16.

## 2. Audit checklist
| Item | Status | Note |
|---|---|---|
| Install/run on Linux with the zip's macOS node_modules | FAIL (before) -> PASS | DB fallback fixed |
| Original test suite | FAIL (1 file crashed) -> PASS | same cause |
| Report list/open/ownership/export lifecycle | PASS | mock data |
| Original "My Reports not viewable" complaint | NOT VERIFIED | could not be reproduced here; real environment unknown |
| False negatives when DNS is unreachable (No SPF/DMARC/CAA) | FAIL (before) -> PASS | |
| Evidence table status hard-coded "ok" | FAIL (before) -> PASS | |
| Redirect / DNS-rebinding guard | FAIL (before) -> PASS | function and loopback tests; internet redirect chain NOT RUN |
| Reserved hostnames (.localdomain etc.) | FAIL (before) -> PASS | |
| Duplicate report on cache hit | FAIL (before) -> PASS | |
| Mobile overflow at 320-1920 px | FAIL at 375 (before) -> PASS | scripted browser |
| XSS from stored third-party text | PASS | scripted browser, malicious title/JSON-LD/og |
| Cookie flags in production, rate-limit under load, account-deletion cascade | NOT RUN | |
| Guest mode: scan/export without login, no access to accounts, reports, dashboard or settings | PASS | guest.test.js (API) + scripted browser run on mock data |
| IP lookups saved to My Reports and counted on the dashboard | FAIL (before) -> PASS | saved as kind "ip"; a bug where they were never counted (wrong id passed to the scan log) was found and fixed |
| Report section order | FAIL (before) -> PASS | follows the prompt's A-P order; checked in the exported PDF |

## 3. Source availability matrix (prompt 13)
All free, no key required. "Live" = called on the real internet by me: none were (BLOCKED).
| Source | Used for | Key | Live check |
|---|---|---|---|
| Node DNS, target website/TLS (direct requests) | DNS, headers, cookies, certificate, site profile | none | BLOCKED |
| WHOIS servers, rdap.org | registration | none | BLOCKED |
| crt.sh, AlienVault OTX, Anubis | subdomains | none | BLOCKED |
| CertSpotter, HackerTarget, urlscan.io, Wayback CDX (SoftInza engine) | subdomain fallback | none | BLOCKED |
| RIPEstat | ASN / geo | none | BLOCKED |
| Shodan InternetDB | ports / CVEs (unverified, may be stale) | none | BLOCKED |
| CISA KEV | exploited-CVE match | none | BLOCKED |
| OpenPhish feed, Feodo blocklist | threat match | none | BLOCKED |
| URLhaus | threat match | optional free key | NOT RUN |
| GitHub API, Wikidata | org footprint, company lookup | none | BLOCKED |
| Subfinder, Amass, theHarvester, SpiderFoot, Recon-ng | optional, opt-in via EXTERNAL_TOOLS | none | NOT VERIFIED (fake binaries only) |
| Google dorks | link generation only; no scraping | none | NOT APPLICABLE |
Works locally without any external service: the app, auth, database, report export, workspace UI. Everything that collects data depends on the services above.

## 4. Delivery summary (prompt 19)
1. Codebase summary: section 1.
2. Confirmed defects: section 2 (FAIL rows) and CHANGES.md.
3-5. Changes, new and preserved functionality: CHANGES.md. Existing routes, accounts, DB schema and collectors were kept; changes are additive.
6. Database: one additive table `scans` (+ index). No existing table altered.
7. Engines actually available: built-in collectors and SoftInza fallback engine (offline-tested only); external tools only if you install and enable them.
8. Source limitations: section 3.
9-10. Test and export results: TEST-REPORT.md (46 automated tests pass; PDF/DOCX/JSON export verified on mock data).
11. Security: SSRF/redirect/rebinding guard added; XSS check passed on mock; remaining risks: internet redirect chain, production cookie flags, load limits not run.
12-14. Deployment, environment variables, free-hosting limits: DEPLOY.md and .env.example. Local SQLite on ephemeral free hosting can lose all data.
15. Known issues and next steps: see below.

## 5. Known issues / next steps
Verify on your real setup (domain scan, My Reports, live sources, real tools, real logo). Not built: common adapter interface for old collectors, DOCX watermark/graph image, tables in PDF/DOCX, freshness/last-seen/UNAVAILABLE finding fields, central design system, DB concurrency audit, Terms/Privacy pages.
**Not production-ready**: the original report-viewing complaint is unresolved and live sources are unverified.
