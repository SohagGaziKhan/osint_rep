require("./lib/env");
const express = require("express");
const path = require("path");
const { assertPublicName, runRecon, normalizeDomain, ReconError } = require("./lib/recon");
const { buildModel } = require("./lib/reportModel");
const { toDocx, toPdf } = require("./lib/reportExport");
const L = require("./lib/limiter");
const A = require("./lib/auth");
const { ipScan } = require("./lib/lookupModule");
const { companyLookup } = require("./lib/companyLookup");

const app = express();
const PORT = process.env.PORT || 5100;
const HOST = process.env.HOST || "127.0.0.1"; // local only by default; set HOST=0.0.0.0 to expose
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1); // behind nginx/Cloudflare: real client IP and https detection
app.disable("x-powered-by");

// Security headers + block cross-site state-changing requests
app.use((req, res, next) => {
  res.set({ "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin",
    "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'" });
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method) && req.headers.origin) {
    let same = false; try { same = new URL(req.headers.origin).host === req.headers.host; } catch {}
    if (!same) return res.status(403).json({ error: "Cross-site request blocked." });
  }
  next();
});

const getToken = (req) => { const m = /(?:^|;\s*)sid=([^;]+)/.exec(req.headers.cookie || ""); return m ? m[1] : null; };
const setCookie = (req, res, token, maxAge) => res.setHeader("Set-Cookie", `sid=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${req.secure || process.env.COOKIE_SECURE === "1" ? "; Secure" : ""}`);
app.use((req, res, next) => { req.token = getToken(req); req.user = A.userFromToken(req.token); next(); });
const needUser = (req, res, next) => (req.user ? next() : res.status(401).json({ error: "Please log in." }));
// ---- Guest mode: scan, IP lookup and export of the CURRENT result only. Nothing about a guest is written to the database.
const GUEST_ON = process.env.ALLOW_GUEST !== "0";
const CANCEL_ON_DISCONNECT = process.env.CANCEL_ON_DISCONNECT !== "0"; // 0 = a scan whose browser tab closes still finishes and is saved (the Cancel button then only hides the result)
const GUEST_MAX = Math.min(Math.max(1, +process.env.GUEST_RATE_LIMIT || 2), Math.max(1, +process.env.RATE_LIMIT || 3)); // guest limit can never exceed the account limit
const GUEST_CAP = Math.max(1, +process.env.GUEST_MAX_CONCURRENT || 3);
const guestKey = (req) => "g" + require("crypto").createHash("sha256").update(String(req.ip || "")).digest("hex").slice(0, 16);
const needAny = (req, res, next) => (req.user ? next() : GUEST_ON ? ((req.guest = true), next()) : res.status(401).json({ error: "Please log in." }));
let guestActive = 0; const xhits = new Map();
const aud = (req, action, detail) => SL.audit(req.user ? req.user.id : null, action, (req.guest ? "[guest] " : "") + (detail || ""), guestKey(req)); // what happened, never report contents
const guestGate = (req, res, next) => { if (!req.guest) return next(); if (guestActive >= GUEST_CAP) return res.status(503).json({ error: "Guest scans are busy right now. Please try again shortly or sign in." }); guestActive++; res.on("close", () => { guestActive--; }); next(); };
const guestExportGate = (req, res, next) => { if (!req.guest) return next(); if (process.env.GUEST_EXPORT === "0") return res.status(403).json({ error: "Exports are available after signing in." });
  const k = guestKey(req), now = Date.now(), a = (xhits.get(k) || []).filter((t) => now - t < 3600000); if (a.length >= 10) return res.status(429).json({ error: "Too many exports. Please wait before trying again." });
  if (xhits.size > 5000) xhits.clear(); a.push(now); xhits.set(k, a); next(); };
const J = express.json({ limit: "10kb" });
const ipOf = (req) => req.ip || (req.socket && req.socket.remoteAddress) || "unknown";
const fail = (res, e) => { if (e instanceof A.AuthError) return res.status(e.status).json({ error: e.message }); console.error(e); res.status(500).json({ error: "Something went wrong." }); };
const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : "");

app.use(express.static(path.join(__dirname, "public"), { index: false })); // login, privacy, terms (public)
app.get("/api/session", (req, res) => { if (req.user) return res.json({ guest: false }); if (!GUEST_ON) return res.json({ guest: false, guestAllowed: false }); req.guest = true; res.json({ guest: true, rate: qstatus(req), exportAllowed: process.env.GUEST_EXPORT !== "0", note: "Guest results stay in this browser tab and are not saved to any account. A scanned domain's public data may be cached on the server for up to 24 hours, not tied to you." }); });
app.get("/scan", (req, res) => { if (!req.user && !GUEST_ON) return res.redirect("/login"); res.set("Cache-Control", "no-store"); res.sendFile(path.join(__dirname, "views", "app.html")); });
// ---- Background jobs (signed-in users only)
const jobs = require("./lib/jobs"), JOBID = /^[a-f0-9]{16}$/;
const fakeReq = (userId) => ({ user: { id: userId }, guest: false, ip: null });
jobs.init({ runRecon, message: (e) => (e instanceof ReconError ? e.message : "Failed to complete recon."), refund: (u) => L.refund("u" + u),
  finish: (u, report) => { const rq = fakeReq(u); finish(rq, report); return { reportId: rq.savedId || null }; },
  cancelled: (r) => { const rq = fakeReq(r.user_id); aud(rq, "scan_cancelled", r.domain + " (background)"); SL.record(r.user_id, { domain: r.domain, status: "cancelled" }); },
  failed: (r, err) => { L.refund("u" + r.user_id); logFail(fakeReq(r.user_id), r.domain, err); } });
app.post("/api/jobs", needUser, J, (req, res) => {
  const body = req.body || {}; try { assertPublicName(body.domain); } catch (e) { return res.status(400).json({ error: e.message }); } // a bad name must not cost quota
  const p = precheck(req, res); if (!p) return;
  if (p.cached) { SL.decorateFindings(req.user.id, p.cached, { cached: true }); keepCached(req, p.cached); logScan(req, p.cached, true); aud(req, "scan_completed", p.cached.domain + " (cached)");
    const have = A.listReports(req.user.id).find((x) => x.domain === p.cached.domain && x.kind !== "ip"); return res.json({ job: { id: null, status: "completed", domain: p.cached.domain, cached: true, reportId: have ? have.id : null }, rate: qstatus(req) }); }
  const r = jobs.enqueue(req.user.id, normalizeDomain(body.domain), body.refresh === true);
  if (r.error) { L.refund(uid(req)); return res.status(r.status).json({ error: r.error }); }
  aud(req, "job_queued", r.job.domain); res.status(202).json({ job: r.job, rate: qstatus(req) });
});
app.get("/api/jobs", needUser, (req, res) => res.json({ jobs: jobs.list(req.user.id) }));
app.get("/api/jobs/:id", needUser, (req, res) => { const j = JOBID.test(req.params.id) ? jobs.get(req.user.id, req.params.id) : null; j ? res.json({ job: j }) : res.status(404).json({ error: "Job not found." }); });
app.post("/api/jobs/:id/cancel", needUser, (req, res) => { const r = JOBID.test(req.params.id) ? jobs.cancel(req.user.id, req.params.id) : null; r ? res.json(r) : res.status(404).json({ error: "Job not found." }); });
app.get("/api/findings", needUser, (req, res) => res.json(SL.findingsList(req.user.id, { limit: +req.query.limit || 20, offset: +req.query.offset || 0, sev: req.query.sev, ver: req.query.ver, q: req.query.q })));
app.get("/api/sources", needUser, (req, res) => res.json({ sources: SL.sourceHealth().map((x) => ({ ...x, circuit: { open: require("./lib/breaker").isOpen(x.collector), retryInSec: require("./lib/breaker").retryIn(x.collector), failures: require("./lib/breaker").failures(x.collector) } })), circuits: require("./lib/breaker").snapshot(), note: "Aggregated over all signed-in scans on this server. States come from the most recent run of each collector; targets and raw errors are never shown." }));
app.get("/api/audit", needUser, (req, res) => res.json({ entries: SL.auditList(req.user.id, +req.query.limit || 50) }));
app.get("/api/engines", needUser, async (req, res) => res.json({ engines: await require("./lib/engines").list(), note: "Subfinder, Amass (passive), theHarvester, SpiderFoot (passive) and Recon-ng are used only when EXTERNAL_TOOLS enables them and they are installed. If none of them gives a usable result, SoftInza's built-in engine is used (SOFTINZA_ENGINE=auto|always|off). The core workflow needs none of them." }));
app.get("/api/engine-registry", needUser, (req, res) => { const l = A.listReports(req.user.id)[0]; const r = l && A.getReport(req.user.id, l.id); res.json({ basedOn: r ? { domain: r.domain, generatedAt: r.generatedAt } : null, families: r ? require("./lib/engineRegistry").status(r) : require("./lib/engineRegistry").FAMILIES.map(([name], i) => ({ n: i + 1, name, status: "not run (no saved report)", collectors: [] })) }); });
app.get("/api/dashboard", needUser, (req, res) => {
  const cov = {};
  try { for (const x of A.listReports(req.user.id).slice(0, 30)) { const r = A.getReport(req.user.id, x.id); if (r && r.kind === "ip") continue; ((r && r.evidence) || []).forEach((e) => { const c = (cov[e.module] = cov[e.module] || { ok: 0, nodata: 0, failed: 0 }), s = String(e.status); if (s === "ok") c.ok++; else if (/^(failed|blocked)/.test(s)) c.failed++; else c.nodata++; }); } } catch (e) { console.error("coverage failed:", e.message); }
  let latestFindings = [], recentReports = [];
  try { const lst = A.listReports(req.user.id); recentReports = lst.slice(0, 5).map((x) => ({ id: x.id, domain: x.domain, risk: x.risk, createdAt: x.createdAt || x.created_at, kind: x.kind }));
    const dbf = SL.findingsList(req.user.id, { limit: 6 }).findings; if (dbf.length) latestFindings = dbf.map((f) => ({ id: f.id, sev: f.sev, msg: f.msg, verification: f.verification, domain: f.domain, freshness: f.freshness, lastSeenAt: f.lastSeenAt, availability: f.availability }));
    const lr = !dbf.length && lst.find((x) => x.kind !== "ip"); if (lr) { const rp = A.getReport(req.user.id, lr.id), rank = { high: 0, medium: 1, low: 2 };
      latestFindings = ((rp && rp.risk && rp.risk.findings) || []).slice().sort((a, b) => (rank[a.sev] ?? 3) - (rank[b.sev] ?? 3)).slice(0, 6).map((f) => ({ id: f.id, sev: f.sev, msg: f.msg, verification: f.verification, domain: rp.domain, freshness: f.freshness, lastSeenAt: f.lastSeenAt, availability: f.availability })); } }
  catch (e) { console.error("dashboard lists failed:", e.message); }
  res.json({ ...SL.dashboard(req.user.id, Math.min(90, Math.max(7, +req.query.days || 14))), coverage: cov, audit: SL.auditList(req.user.id, 8), latestFindings, recentReports });
});
// Public branding/contact comes ONLY from environment variables. Nothing is invented: unset values are simply not shown.
app.get("/api/public/config", (req, res) => res.json({ brand: process.env.BRAND_NAME || "SoftInza OSINT", guest: GUEST_ON, tagline: require("./lib/brand").tagline(), logoUrl: /^\/[\w./-]+$/.test(process.env.BRAND_LOGO || "") ? process.env.BRAND_LOGO : "",
  legal: { terms: safeUrl(process.env.TERMS_URL) || "", privacy: safeUrl(process.env.PRIVACY_URL) || "" }, contact: { text: process.env.CTA_TEXT || "", url: safeUrl(process.env.CTA_URL) || "", email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(process.env.CONTACT_EMAIL || "") ? process.env.CONTACT_EMAIL : "" } }));
app.get("/", (req, res) => { if (!req.user) return res.sendFile(path.join(__dirname, "views", "home.html")); res.set("Cache-Control", "no-store"); res.sendFile(path.join(__dirname, "views", "app.html")); });
app.get("/login", (req, res) => (req.user ? res.redirect("/") : res.sendFile(path.join(__dirname, "public", "login.html"))));
app.get("/api/health", (req, res) => res.json({ status: "ok" }));

// ---- auth
app.get("/api/auth/config", (req, res) => res.json({ signup: process.env.ALLOW_SIGNUP !== "0" }));
app.use((req, res, next) => { if (req.method === "POST" && /^\/api\/auth\/(login|register|logout)$/.test(req.path)) res.on("finish", () => SL.audit(null, "auth_" + req.path.split("/").pop(), "status " + res.statusCode, guestKey(req))); next(); });
app.post("/api/auth/register", J, async (req, res) => { try { const id = await A.register({ ...(req.body || {}), ip: ipOf(req) }); setCookie(req, res, A.createSession(id), 14 * 86400); res.json({ ok: true }); } catch (e) { fail(res, e); } });
app.post("/api/auth/login", J, async (req, res) => { try { const id = await A.login({ ...(req.body || {}), ip: ipOf(req) }); setCookie(req, res, A.createSession(id), 14 * 86400); res.json({ ok: true }); } catch (e) { fail(res, e); } });
app.post("/api/auth/logout", J, (req, res) => { A.destroySession(req.token); setCookie(req, res, "", 0); res.json({ ok: true }); });
app.get("/api/auth/me", needUser, (req, res) => res.json({
  user: req.user, rate: L.status("u" + req.user.id), reportCount: A.listReports(req.user.id).length,
  config: { softinzaUrl: safeUrl(process.env.SOFTINZA_URL), ctaText: process.env.CTA_TEXT || "", ctaUrl: safeUrl(process.env.CTA_URL) },
}));

// ---- account
app.post("/api/account/profile", needUser, J, (req, res) => { A.updateName(req.user.id, (req.body || {}).name); res.json({ ok: true }); });
app.post("/api/account/password", needUser, J, async (req, res) => { try { const b = req.body || {}; await A.changePassword(req.user.id, b.current, b.next, req.token); res.json({ ok: true }); } catch (e) { fail(res, e); } });
app.post("/api/account/delete", needUser, J, async (req, res) => { try { await A.deleteAccount(req.user.id, (req.body || {}).password); setCookie(req, res, "", 0); res.json({ ok: true }); } catch (e) { fail(res, e); } });

// ---- saved reports (per user)
app.get("/api/reports", needUser, (req, res) => res.json({ reports: A.listReports(req.user.id) }));
app.get("/api/reports/:id", needUser, (req, res) => { const r = /^\d+$/.test(req.params.id) ? A.getReport(req.user.id, +req.params.id) : null; r ? res.json(r) : res.status(404).json({ error: "Report not found." }); });
app.delete("/api/reports/:id", needUser, (req, res) => { aud(req, "report_deleted", "id " + req.params.id); const ok = /^\d+$/.test(req.params.id) && A.deleteReport(req.user.id, +req.params.id); ok ? res.json({ ok: true }) : res.status(404).json({ error: "Report not found." }); });

// ---- scans (login required; quota is per account)
app.get("/api/limit", needUser, (req, res) => res.json(L.status("u" + req.user.id)));
const uid = (req) => (req.guest ? guestKey(req) : "u" + req.user.id);
const qstatus = (req) => { const st = L.status(uid(req)); if (!req.guest) return st; const used = st.limit - st.remaining; return { ...st, limit: GUEST_MAX, remaining: Math.max(0, GUEST_MAX - used) }; };
function precheck(req, res) {
  const body = req.body || {};
  if (body.consent !== true) { res.status(400).json({ error: "Please confirm you own this domain or are authorised to assess it." }); return null; }
  const c = body.refresh === true ? null : L.getCached(normalizeDomain(body.domain)); // cached reports do not use quota; refresh:true forces a fresh scan (uses quota)
  if (c) return { cached: { ...JSON.parse(JSON.stringify(c.report)), cached: true, cacheInfo: { generatedAt: new Date(c.at).toISOString(), expiresAt: new Date(c.expiresAt).toISOString() }, rate: qstatus(req) } };
  const st = qstatus(req);
  if (st.remaining <= 0) { res.status(429).json({ error: `Limit reached: ${st.limit} reports per ${st.windowMin} minutes.`, retryAfterSec: st.resetInSec, limit: st.limit }); return null; }
  L.consume(uid(req));
  return { domain: body.domain };
}
const SL = require("./lib/scanLog");
const D = require("./lib/db");
const keepCached = (req, r) => { if (req.guest) return false; try { const t = Date.parse(r.generatedAt) || 0; if (D.prepare("SELECT 1 x FROM reports WHERE user_id=? AND domain=? AND created_at>=?").get(req.user.id, r.domain, t - 5000)) return true; } catch {} return keep(req, r); };
const keep = (req, report) => { if (req.guest) return false; try { req.savedId = A.saveReport(req.user.id, report); return true; } catch (e) { console.error("save report failed:", e.message); return false; } };
const logScan = (req, report, cached) => req.guest ? null : SL.record(req.user.id, { domain: report.domain, status: "completed", risk: report.risk && report.risk.level, findings: ((report.risk && report.risk.findings) || []).length, cached, sev: ((report.risk && report.risk.findings) || []).reduce((o, f) => (o[f.sev] = (o[f.sev] || 0) + 1, o), {}), partial: (report.evidence || []).some((e) => e.status !== "ok"), verified: ((report.risk && report.risk.findings) || []).filter((f) => f.verification === "VERIFIED").length });
// Rejected input (invalid/internal target) never started a scan, so only genuine collection failures count as failed scans.
const logFail = (req, domain, err) => { if (!(err instanceof ReconError)) aud(req, "scan_failed", domain + (err && err.message ? ": " + String(err.message).slice(0, 80) : "")); if (!req.guest && !(err instanceof ReconError)) SL.record(req.user.id, { domain, status: "failed" }); };
const finish = (req, report) => {
  L.setCached(report.domain, JSON.parse(JSON.stringify(report)));
  SL.decorateFindings(req.guest ? null : req.user.id, report);
  const saved = keep(req, report); logScan(req, report, false);
  if (!req.guest) { SL.recordRuns(req.user.id, report); SL.recordInvestigation(req.user.id, report); }
  aud(req, "scan_completed", report.domain);
  return { ...report, saved, cached: false, cacheInfo: { generatedAt: report.generatedAt, expiresAt: new Date(Date.now() + L.TTL).toISOString() }, rate: qstatus(req) };
};

app.post("/api/recon", needAny, guestGate, J, async (req, res) => {
  const p = precheck(req, res); if (!p) return;
  if (p.cached) { SL.decorateFindings(req.guest ? null : req.user.id, p.cached, { cached: true }); const saved = keepCached(req, p.cached); logScan(req, p.cached, true); aud(req, "scan_completed", p.cached.domain + " (cached)"); return res.json({ ...p.cached, saved }); }
  try { res.json(finish(req, await runRecon(p.domain))); }
  catch (err) {
    L.refund(uid(req)); logFail(req, p.domain, err); // failed or invalid requests do not use quota
    if (err instanceof ReconError) return res.status(err.status).json({ error: err.message });
    res.status(500).json({ error: "Failed to complete recon.", detail: err.message });
  }
});

// Same as /api/recon but streams one JSON line per finished collector, then {done: report}
app.post("/api/recon/stream", needAny, guestGate, J, async (req, res) => {
  const p = precheck(req, res); if (!p) return;
  res.set({ "Content-Type": "application/x-ndjson", "Cache-Control": "no-cache", "X-Accel-Buffering": "no" });
  // Client disconnected before the report was finished = cancelled. The quota is NOT refunded (the work already ran) and the result is discarded.
  let gone = false; res.on("close", () => { if (!res.writableEnded) gone = true; });
  const w = (o) => { if (!gone) res.write(JSON.stringify(o) + "\n"); };
  if (p.cached) { SL.decorateFindings(req.guest ? null : req.user.id, p.cached, { cached: true }); const saved = keepCached(req, p.cached); logScan(req, p.cached, true); aud(req, "scan_completed", p.cached.domain + " (cached)"); w({ done: { ...p.cached, saved } }); return res.end(); }
  try { const rep = await runRecon(p.domain, (name, ok) => w({ progress: name, ok }));
    if (gone && CANCEL_ON_DISCONNECT) { aud(req, "scan_cancelled", p.domain); if (!req.guest) SL.record(req.user.id, { domain: p.domain, status: "cancelled" }); return; }
    w({ done: finish(req, rep) }); }
  catch (err) { if (gone && CANCEL_ON_DISCONNECT) { aud(req, "scan_cancelled", p.domain); if (!req.guest) SL.record(req.user.id, { domain: p.domain, status: "cancelled" }); return; } L.refund(uid(req)); logFail(req, p.domain, err); w({ error: err instanceof ReconError ? err.message : "Failed to complete recon." }); }
  res.end();
});

// Word / PDF export of a report the browser already holds
app.post("/api/export/:fmt", needAny, guestExportGate, express.json({ limit: "8mb" }), async (req, res) => {
  const r = req.body && req.body.report, fmt = req.params.fmt;
  if (!r || typeof r.domain !== "string" || !["docx", "pdf"].includes(fmt)) return res.status(400).json({ error: "Invalid export request." });
  try {
    const m = buildModel(r);
    const only = Array.isArray(req.body.only) ? req.body.only.filter((k) => typeof k === "string" && k.length <= 40).slice(0, 10) : null;
    if (only && only.length) { m.sections = m.sections.filter((s) => /Coverage/.test(s.title) || only.some((k) => s.title.includes(k))); m.title += " - Module Extract"; }
    aud(req, "export", `${fmt} ${r.domain}${only && only.length ? " (module)" : ""}`);
    const buf = fmt === "docx" ? await toDocx(m) : await toPdf(m);
    res.set({ "Content-Type": fmt === "docx" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/pdf", "Content-Disposition": `attachment; filename="softinza-${r.domain.replace(/[^a-z0-9.-]/gi, "_")}${only && only.length ? "-module" : ""}.${fmt}"` }).send(buf);
  } catch (err) { res.status(500).json({ error: "Export failed.", detail: err.message }); }
});

// ---- IP lookup (uses 1 quota) and company-name -> domain finder (light throttle)
const lookupHits = new Map();
const throttled = (id) => { const now = Date.now(), a = (lookupHits.get(id) || []).filter((t) => now - t < 36e5); a.push(now); lookupHits.set(id, a); return a.length > 20; };
app.post("/api/ipscan", needAny, guestGate, J, async (req, res) => {
  const b = req.body || {};
  if (b.consent !== true) return res.status(400).json({ error: "Please confirm you are authorised to assess this IP address." });
  const st = qstatus(req);
  if (st.remaining <= 0) return res.status(429).json({ error: `Limit reached: ${st.limit} reports per ${st.windowMin} minutes.`, retryAfterSec: st.resetInSec, limit: st.limit });
  L.consume(uid(req));
  try { const out = await ipScan(b.ip); aud(req, "ip_lookup", b.ip); if (!req.guest) { SL.record(req.user.id, { domain: b.ip, kind: "ip", status: "completed" }); keep(req, { ...out, kind: "ip", domain: out.ip || b.ip }); } res.json({ ...out, rate: qstatus(req) }); }
  catch (err) { L.refund(uid(req)); if (err.status !== 400 && !req.guest) SL.record(req.user.id, { domain: b.ip, kind: "ip", status: "failed" }); res.status(err.status || 500).json({ error: err.status ? err.message : "IP lookup failed." }); }
});
app.post("/api/company-lookup", needUser, J, async (req, res) => {
  if (throttled(uid(req))) return res.status(429).json({ error: "Too many lookups. Try again later." });
  try { res.json({ results: await companyLookup((req.body || {}).name) }); }
  catch (err) { res.status(err.status || 502).json({ error: err.status ? err.message : "The company lookup service is unavailable right now." }); }
});

app.listen(PORT, HOST, () => console.log(`SoftInza OSINT running on http://${HOST}:${PORT}`));
