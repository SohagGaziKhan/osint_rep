# Deployment notes (read before going live)

- **Data location:** accounts, sessions and reports live in `data/softinza.db` (SQLite). Set `DATA_DIR` to a persistent volume and back it up.
- **Free hosting warning:** many free tiers (e.g. ephemeral container disks) erase local files on restart or redeploy. You would lose users and reports. Use a host with a persistent disk, or do not rely on free ephemeral storage. This project has NOT been tested on any specific free host.
- **Guest mode:** on by default (`ALLOW_GUEST=0` turns it off). Guest scans are limited per client IP (default 2 per hour) and by a server-wide concurrency cap. Behind a proxy you MUST set `TRUST_PROXY=1`; otherwise all guests share one IP and one quota (safe, but guests get locked out). An attacker who rotates IP addresses can still use the guest quota, so keep the limits low and watch the logs. Guest results live only in the browser tab; the server keeps only a hashed-IP counter (limiter.json) and the usual 24 h public-data cache of a scanned domain.
- **Run:** Node 20+ (Node 22.5+ also works without the native SQLite module). `npm install`, copy `.env.example` to `.env`, `npm start`. Behind a reverse proxy set `TRUST_PROXY=1` and, on HTTPS, `COOKIE_SECURE=1`. Keep `HOST=127.0.0.1` unless a proxy is in front.
- **Optional tools:** install any of Subfinder, Amass, theHarvester, SpiderFoot, Recon-ng yourself and list them in `EXTERNAL_TOOLS`. Check each tool's licence before redistributing it.
- **Outbound network:** the server must reach public sources. Internal/private addresses are refused by design (SSRF guard).
- **Branding:** `BRAND_NAME`, `BRAND_LOGO` (web path), `BRAND_LOGO_FILE` (PNG/JPG for PDF/DOCX), `CTA_URL`, `CONTACT_EMAIL`, `TERMS_URL`, `PRIVACY_URL`. Unset values are simply not shown.
- **Time limits:** a scan can take about a minute; SpiderFoot up to five. Host request time limits must allow this.
