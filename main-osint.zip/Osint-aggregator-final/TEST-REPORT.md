# Test report (what was actually run)

Environment: Linux sandbox, Node 22, **no internet**. All scans used an offline mock (tests/helpers/netmock.js, TEST DATA) and fake tool binaries. Live sources and real external tools were never called.

| Area | Status | Evidence |
|---|---|---|
| Automated suite (`npm test`) | PASS | 68/68 |
| Background jobs API: FIFO queue with one worker, runs without the browser and saves normal reports, cancel refunds only a waiting job, late finish cannot overwrite a cancel, ownership and guest 401, bad names cost no quota, per-user active limit with refund, restart marks jobs interrupted | PASS | jobs.test.js (real server, slow mock, real kill and restart) |
| Background jobs in the browser: checkbox, tab closed mid-scan then report found after returning, Dashboard card with Open and Cancel, cancel from the scan page, hidden for guests, no overflow at 320 px | PASS (one scripted run; not stored as an automated test) | scripted browser run |
| Circuit breaker: opens after N failures, one trial after the cooldown, re-opens on a failed trial, skipped runs not counted, other sources unaffected, only reachability errors count, target-facing collectors never guarded | PASS | breaker.test.js (unit) + breaker.server.test.js (real server, 5.5 s cooldown) |
| Stored findings (/api/findings filters, paging, isolation, guest 401) and investigations rows equal the scan's finding count; dashboard latest findings from the database | PASS | api.test.js + direct read of the tables |
| Grouped Scan Center menu on desktop, 320 px touch device (drawer stays open, items on screen) and for guests; DOCX Contents list | PASS | scripted browser run + stored smoke test; DOCX read from document.xml (not visually) |
| Per-finding evidence record, Finding Evidence Appendix, dashboard verified/latest/recent fields, /api/sources (no target leaked, guest 401) | PASS | api.test.js, guest.test.js |
| Workspace findings panel (search, filters, sort, pagination 10+1, expandable evidence), dashboard cards, Settings persisted across reload, no overflow at 320 px, Settings hidden for guests | PASS | scripted browser run |
| Circuit breaker / throttling for failing sources | NOT BUILT | |
| Execution timeline consistency (every started collector ends once, timestamps never go back), stored collector runs, per-user audit log (no email/password stored), guest blocked from /api/audit | PASS | api.test.js + guest.test.js + direct read of the audit_log table |
| Dashboard module usage / source status / failed tasks / activity log / quick actions; workspace timeline; 320 px overflow after the fix | PASS | scripted browser run |
| Cancel mid-scan (real disconnect): result discarded, nothing saved, quota not refunded, counted as cancelled; refresh:true forces a fresh scan | PASS | cancel.test.js (slow mock) |
| Scan UI: elapsed/finished/failed line, Cancel, Try again, Re-run button on a failed scan and its consent check, theme toggle saved across reload | PASS (re-run with the box ticked NOT run in the UI; it shares the refresh path covered by Try again and the API test) | scripted browser run |
| Guest mode: public routes only, 401 on all account/report/dashboard/engine routes, quota 2 then 429, cache hit free, IP lookups share the quota, nothing saved or leaked to accounts, export works, ALLOW_GUEST=0 and GUEST_EXPORT=0 honoured | PASS | guest.test.js (real HTTP, mock data) |
| Guest UI: homepage CTA, /scan without login, hidden Reports/Account, scan, workspace, PDF export, session dashboard, survives reload, isolated per tab, no failed requests, mobile no overflow | PASS | scripted browser run |
| Guest quota bypass by IP rotation, behaviour behind a real proxy | NOT RUN | |
| PDF table of contents (21 entries checked against the real pages), tagline, cover Investigation ID | PASS | pdftotext on an exported PDF (mock data) |
| Six-status classification incl. offline run with every source unreachable (no VERIFIED, no false NOT FOUND) | PASS | classification.test.js + scan without mock |
| A-P section order (exported PDF), module extracts (PDF/DOCX), IP lookup saved/opened/counted | PASS | api.test.js + scripted browser run |
| Severity markers in PDF | PASS (visual); DOCX colour NOT visually checked | rendered page |
| Dashboard severity + gaps, Help view, dork explanations/presets, graph PNG/SVG (valid files), export double-click guard | PASS | scripted browser run |
| WHOIS vs RDAP disagreement (CONTRADICTED) | PASS on synthetic data; NOT VERIFIED on a real domain | disagreements.test.js, PDF/DOCX text |
| Finding ids + verification labels; engine family status (12 families) | PASS | api.test.js, exported PDF text |
| Stored browser smoke test (10 tabs x 320/768/1440 px, XSS, overflow) | PASS | tests/browser/smoke.js (needs playwright) |
| Guest blocked from private routes | PASS | api.test.js |
| User A cannot read User B's report / dashboard | PASS | api.test.js |
| Invalid / traversal-style report ids | PASS | api.test.js (404/400) |
| Consent required, internal targets blocked | PASS | api.test.js |
| SSRF variants (localhost.localdomain, decimal/hex IP, userinfo, 169.254.169.254, [::1], 10/192.168/172.16) | PASS (one real gap found and fixed: `.localdomain` etc.) | api.test.js, safehttp.test.js |
| Connection-time guard against DNS answers that point inside | PASS | safehttp.test.js on real loopback network stack |
| Redirect to an internal IP literal aborted | PASS (function level) | safehttp.test.js. A full redirect chain over the real internet was NOT run |
| Dashboard counts (completed/failed/cached/no double counting, isolation) | PASS | scanlog.test.js, api.test.js |
| Report exports: DOCX, PDF open and contain Methodology, Summary, ID, Coverage | PASS | file signatures + text extraction |
| PDF logo / watermark / graph page | PASS with a TEST image only | visually inspected; real ShopKingar logo NOT VERIFIED |
| DOCX logo / brand header | PASS (XML inspected); DOCX pages NOT visually inspected | |
| JSON export (Workspace) | PASS | browser download |
| XSS: malicious title / JSON-LD / og tags stored in a report | PASS | scripted browser run: no execution, 0 injected elements, all pages |
| No horizontal overflow at 320/375/414/768/1024/1440/1920 px (home, dashboard, 10 workspace tabs, report) | PASS | scripted browser run |
| Workspace 10 tabs, graph pan/zoom/search/inspect, dork filter | PASS | scripted browser run (not stored as automated tests) |
| Subfinder/Amass/theHarvester/SpiderFoot/Recon-ng adapters | PASS with FAKE binaries; real tools NOT VERIFIED | external.test.js |
| SoftInza built-in engine + fallback rule | PASS with mock; live APIs NOT VERIFIED | engine.test.js |
| Live sources (crt.sh, Shodan, Wayback, OpenPhish, CertSpotter, HackerTarget, urlscan.io) | BLOCKED | no internet |
| `better-sqlite3` driver path | NOT VERIFIED | only `node:sqlite` was exercised |
| Original "My Reports not viewable" complaint | NOT REPRODUCED | everything worked here; real environment unknown |
| Rate-limit enforcement under load, cookie flags in production (COOKIE_SECURE), account deletion cascade | NOT RUN | |
| Free-hosting persistence of SQLite | NOT VERIFIED | known risk: ephemeral disks lose data |

Not production-ready until the original My Reports complaint is checked on your real setup and live sources are verified.
