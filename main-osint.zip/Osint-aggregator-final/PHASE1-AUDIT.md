# Phase 1 audit against the "FINAL MASTER PROJECT PROMPT" (honest status)

Environment of all checks: Linux sandbox, Node 22, **no internet**; scans used an offline mock and fake tool binaries. Nothing below was run against real sources.

## "Existing 14 modules" (prompt section 2)
The repository does **not** name 14 backend modules, and I will not invent names. What exists in code: **18 collectors** wired in lib/recon.js (RDAP, WHOIS, Subdomains, IP & ASN, CISA KEV, Company profile, SSL, Security headers, SPF/DMARC, DNS hardening, Wayback, Archived URLs, Sitemap, robots.txt, security.txt, Lookalikes, Threat feeds, Website), grouped into 10 evidence rows and, in the original report, **14 numbered report sections**. The 14 is most likely those report sections; **please confirm** which list you mean before a final module-to-Scan-Center mapping is written. Nothing was removed.

## Status per prompt requirement
| Requirement (prompt section) | Status |
|---|---|
| Audit deliverables (2): architecture, module inventory, API inventory, DB schema, source inventory, security assessment, UI inventory, gaps, roadmap | PARTIAL: AUDIT.md, TEST-REPORT.md, CHANGES.md, DEPLOY.md and this file; no separate formal documents |
| Internal intelligence library as reusable engines with input/output schemas (4) | PARTIAL: collectors + engineRegistry status mapping; no common schema/adapter interface |
| Kali tool integration: Subfinder, Amass, theHarvester, SpiderFoot, Recon-ng (5) | PARTIAL: opt-in adapters, fake-binary tested only. NOT integrated: DNSRecon, Sherlock, ExifTool, Maltego. No isolated worker, no job queue, no resource limits beyond timeout/output cap |
| Source Manager: per-source health, last success/failure, circuit breakers, throttling (6) | PARTIAL: a health view per collector (state Available / Rate Limited / Blocked / Timeout / Unavailable / Error, runs, success rate, average time, last success and failure, failure streak), aggregated over all signed-in scans, with no targets or raw errors shown. **circuit breaker** for third-party sources, the SoftInza fallback engine's sources and external tools (default 3 failures in a row, skipped 5 minutes, then one trial; only reachability errors count; target-facing collectors are never guarded; in memory, resets on restart). NOT done: request throttling, back-off per source, 'Authentication Required' / 'Not Configured' states |
| Scan Center with live progress, cancel, retry, pagination, source status (7) | PARTIAL: live per-collector progress with elapsed time and finished/failed counts, **Cancel** (closing the connection discards the result, quota not refunded), **Try again** and **Re-run scan (fresh data)** (forces a new scan, needs fresh consent, uses quota). NOT done: background jobs that survive a closed tab or restart, retrying only the failed collectors (a retry re-runs everything), estimated time remaining, pagination of findings |
| Six-status classification (8) | DONE at module level (this pass); findings keep VERIFIED / PARTIALLY VERIFIED / UNVERIFIED |
| Evidence engine with evidence/finding/investigation IDs, verification timestamps, audit history (9) | PARTIAL: finding IDs, investigation ID, source/time/confidence on evidence rows, **real execution timeline** (every collector start/finish/failure with duration, attempts and error, plus a classification event), **audit log**. **per-finding evidence record** (method, collected time, labelling time, limitation, related findings) shown in the Workspace findings list and in the report's Finding Evidence Appendix. NOT done: a separate evidence database table, an independent verification time (the 'labelled' time is when SoftInza applied the label), individual source-request events |
| Dashboard with real stats and 6 graphs, recent activity, quick actions (10) | DONE except the items named below: scans, completed, failed, cancelled, findings, verified findings, reports; scan activity, severity, risk, module coverage, **module usage and source status (from stored collector runs)**; recent scans, **recent failed tasks, activity log**; quick actions to Subdomain, Email/FQDN, Social, Threat. also recent reports and the latest findings. Not built: a list of the most recent findings across ALL reports (it shows the latest report's top findings) |
| Sidebar: Dashboard, Scan Center, Reports, Profile, Settings (11) | PARTIAL: existing sidebar plus a Settings page (theme, default dashboard range, clear saved dork filters; stored in the browser only). Account serves as the profile page. The Scan Center is now a grouped, expandable menu of the 10 categories (verified on desktop, a 320 px touch device and as a guest) |
| **Guest mode** (12) | **DONE** (this pass): scan, IP lookup, workspace, session dashboard and export of the current result without an account; per-IP quota, concurrency cap, export throttle, switchable via env; results only in the browser tab; every other API stays login-only (tested). Limits: IP-based quota can be bypassed by IP rotation; counters for concurrency/export reset on restart |
| Complete reports, 4 formats, TOC, tagline, watermark (13) | PARTIAL: PDF (TOC, tagline, watermark, ID), DOCX, JSON, HTML (browser). Missing: full evidence appendix per finding, investigation timeline from real execution events, DOCX TOC/watermark |
| Light and dark theme with central tokens and toggle (14) | PARTIAL: toggle in the app, saved preference and system default **verified** (light -> dark, kept after reload). CORRECTION: an earlier version of this table said the app had no toggle; that was wrong. NOT audited: whether every colour in every component comes from central tokens |
| Reusable component system (15) | NOT DONE (single-file UI) |
| Relationship graph with verified/unverified edges (16) | PARTIAL: interactive; edges not styled by verification |
| Responsive (17) | DONE at tested widths (320-1920) |
| Frontend on existing stack (18) | Vanilla JS app (not React); not migrated, as the prompt allows |
| DB: guest sessions, investigations, jobs, evidence, sources, timeline, tool logs, audit logs (19) | PARTIAL: users, sessions, reports, scans, **collector_runs** (one row per collector run) and **audit_log**. **investigations** and **findings_log** (one row per finding, used by /api/findings and the dashboard). NOT done: separate jobs, evidence, sources and tool-log tables (the timeline lives inside each report; guests are intentionally not stored) |
| Security (20) | PARTIAL: SSRF/redirect/rebinding guard, XSS, ownership checks, CSRF origin check. audit logging is DONE for scans, exports, IP lookups, report deletes and sign-in outcomes. NOT done: subprocess resource limits, port allow-list |
| Reliability: queue, cancellation, worker health (21) | PARTIAL: **background jobs** (API only, see below), cancellation, circuit breaker, and one-failure-keeps-the-rest. NO worker health monitoring, NO resume after a restart (jobs are marked interrupted), jobs run inside the web server process (no isolated worker). The UI offers a Run-in-the-background option and a Dashboard card |
| Testing (22) | 50 automated tests + browser smoke; IDOR/SSRF/XSS covered on mock data |
| Deployment (23, phase 9) | NOT DONE |

## Proposed roadmap (not started unless marked done above)
1. Confirm the "14 modules" list; write the formal mapping to the 10 Scan Center categories.
2. ~~Guest mode~~ DONE (see table).
3. Job layer: investigation records, background execution, live progress via polling/SSE, cancel and retry.
4. Evidence and timeline tables; audit log; Source Manager with health and circuit breaker.
5. Settings page, theme toggle with saved preference; dashboard gaps.
6. Isolated tool worker; additional tools after licence review.
7. Deployment smoke tests on the real host.
