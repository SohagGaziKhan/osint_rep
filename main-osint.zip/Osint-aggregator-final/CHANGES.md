# Changes in this update (audited and tested)

## Fixed
- lib/db.js: SQLite fallback now also covers a native better-sqlite3 binary that loads but cannot open (e.g. macOS node_modules on Linux). Run `npm install` after copying the project.
- DNS failures no longer produce fake "No SPF / No DMARC / No CAA" findings. A negative is only reported when DNS really answered; otherwise the module is shown as failed.
- Evidence table statuses now come from real data ("ok" / "no data returned" / "failed"), not hard-coded "ok".
- robots.txt / sitemap: network failure is marked `unavailable`, not "not found".
- My Reports: Open now shows the error instead of doing nothing. Reports include `saved: true/false` so a failed save is no longer silent.

## Added
- Public homepage at `/` (2 hero slides, features, how it works, responsible use, contact). Brand/contact come only from env vars: BRAND_NAME, BRAND_LOGO (same-origin path), CTA_TEXT, CTA_URL, CONTACT_EMAIL. Unset values are not shown.
- Dashboard (sidebar "Dashboard") backed by a new additive `scans` table and `/api/dashboard`. History starts from this update; earlier scans were never recorded.
- tests/scanlog.test.js and tests/helpers/netmock.js (offline TEST DATA mock: `node -r ./tests/helpers/netmock.js server.js`).

## Added in the second pass
- Scan Workspace (sidebar "Scan Workspace"): 10 modules (Domain, Subdomains, Email & FQDN, Social, Historical, Search & Dorks, Relationship Graph, Google Dorking, Threat, Reports). Every panel renders only from a saved report's persisted data, shows source/time/status from the evidence table, and shows "no data"/"failed" instead of guesses.
- Interactive relationship graph (pan, zoom, search, click-to-inspect with edge source, SVG download, text alternative list).
- Google Dorking module (37 categorised queries, filter, copy, open). Link builder only: results are not retrieved.
- Email & FQDN: only addresses published on the target site; FQDNs from subdomains, TLS SAN, MX, NS with their observation source. Nothing is guessed.
- Cached scans no longer save a duplicate report for the same user.
- Mobile: long URLs wrap, report view has no horizontal overflow at 375px.

## Added in the third pass
- Exports: brand name and logo come only from env (BRAND_NAME, BRAND_LOGO_FILE = path to a PNG/JPG up to 2 MB, checked by file signature). PDF: logo in every page header, faint logo watermark (6% opacity), vector Relationship Graph page. DOCX: logo and brand in the header.
- Reports now include "Report status" (PARTIAL when any module failed or returned no data) and a "15. Coverage & Limitations" section.
- Subdomains keep the source(s) that discovered them (crt.sh, AlienVault OTX, Anubis); shown in the Scan Workspace.
- IP lookups are counted on the Dashboard. (They are still not saved as reports.)
- GET /api/engines + Workspace "Optional tool availability": detects Subfinder, Amass, theHarvester, SpiderFoot, Recon-ng. Licences listed should be re-checked before redistributing any tool.
- tests/api.test.js: end-to-end API test on the offline mock (auth, consent, SSRF block, ownership, cache dedupe, dashboard, exports, subdomain sources). 25/25 tests pass.

## Not done / known limits
- Logo/watermark: verified only with a test image. No official logo was supplied; set BRAND_LOGO_FILE yourself. DOCX has no watermark and no graph image (DOCX lists relationships in a section instead).
- theHarvester, SpiderFoot and Recon-ng: detected only, NO adapter. Nmap/active scanning intentionally not added.
- IP lookup results are not saved to My Reports (different data shape).
- Original "My Reports not viewable" complaint: NOT REPRODUCED here. better-sqlite3 path and all live sources (crt.sh, Shodan, Wayback, OpenPhish...): NOT VERIFIED (no internet in the test environment).
- Browser UI checks (Workspace, Dashboard, Home, mobile 375px) were scripted runs, not stored as automated tests.

## Fourth pass: external tools actually used (opt-in, all passive)
- lib/externalTools.js: Subfinder, Amass (passive), theHarvester, SpiderFoot (passive use case) and Recon-ng feed subdomain discovery and an "external emails" list. Off by default. Enable with `EXTERNAL_TOOLS=subfinder,amass,theharvester,spiderfoot,reconng` AND install the binaries.
- Commands (flags confirmed from each tool's public docs, not from running them):
  - `subfinder -d <domain> -silent`
  - `amass enum -passive -d <domain> -nocolor`
  - `theHarvester -d <domain> -b crtsh,otx,hackertarget,rapiddns -l 200 -f <tmp>/out` (reads <tmp>/out.json; override sources with THEHARVESTER_SOURCES; binary with THEHARVESTER_CMD)
  - `spiderfoot -s <domain> -u passive -F INTERNET_NAME,EMAILADDR -o json -q` (SPIDERFOOT_CMD may point to sf.py)
  - `recon-cli -w softinza -m <module> -o SOURCE=<domain> -x` for each module in RECONNG_MODULES (default hackertarget + certificate_transparency; modules must already be installed in Recon-ng)
- Safety: execFile (no shell), strict domain check, env values validated, per-tool timeouts (override EXTERNAL_TOOL_TIMEOUT_MS), 5 MB output cap, temp dir removed. Output is untrusted text: only hostnames/emails that belong to the target are kept; the domain part of an email is never treated as a host. No DNS brute force, no active scanning, no API-key sources.
- Each name records which tool reported it. Reports list every tool's status in "Coverage & Limitations"; tool emails are labelled unverified.
- VERIFIED only with FAKE executables (tests/external.test.js, 33/33 tests pass, plus a full server run). The REAL tools were NOT run (not installed here, no internet), so real output formats, version differences and Recon-ng module availability are NOT VERIFIED. Run each tool's version command, then a test scan on a domain you own.
- Licences: theHarvester GPL-2.0, Recon-ng GPL-3.0, SpiderFoot MIT, Subfinder MIT, Amass Apache-2.0. The tools are called as separate programs and are not bundled; check licence terms before redistributing any of them with your product.
- Recon-ng keeps its own workspace data under its home directory ("softinza" workspace).

## Fifth pass: SoftInza built-in fallback engine
- lib/softinzaEngine.js: a built-in passive collector that needs no external program. Sources: CertSpotter, HackerTarget, urlscan.io, Wayback (hostnames). It does NOT scrape Google/Bing and does not bypass CAPTCHAs, rate limits or blocks; a refused source is reported as "rate limited" / "blocked (403)" / "unavailable".
- Fallback rule (`SOFTINZA_ENGINE`, default `auto`): the engine runs when no external tool produced a usable result (no tools enabled, not installed, failed, timed out, blocked, or empty). `always` runs it on every scan; `off` disables it. Note: with the default `auto` and no external tools enabled, every scan makes 4 extra requests to those public APIs (nothing is sent to the target).
- External tool output that looks like a search-engine/source block (captcha, unusual traffic, 429/403, too many requests...) is now reported as `blocked`, instead of "ok" with zero results.
- Every name records the engine source (e.g. "SoftInza Engine · CertSpotter"). The report's "Coverage & Limitations" lists each tool and engine status, per-source detail, and why the engine ran. GET /api/engines lists the built-in engine.
- Hostnames only: the engine does not collect emails.
- VERIFIED with the offline mock and fake tool binaries (37/37 tests pass, plus a full server run: blocked tool + auto -> engine used; blocked tool + off -> engine not used). The four public APIs were NOT called live (no internet in the test environment), so their current availability, free-tier limits and request formats are NOT VERIFIED. Parsing is tolerant text matching, but URLs and parameters come from public documentation knowledge.

## Sixth pass: reports, dashboard, homepage, security
- Reports: Investigation ID (INV-xxxx) in the Executive Summary; cover title follows BRAND_NAME; new unnumbered sections "Investigation Methodology" (from the real evidence table) and "Investigation Summary" (counts, unknowns). 19 sections total.
- Dashboard: scans-by-overall-risk, module coverage across your latest 30 saved reports (ok / no data / failed-or-blocked), 7/14/30/90-day range, "Open latest report".
- Workspace: "Download this module (JSON)" per module.
- Homepage: modules list, evidence transparency, graph and report previews (labelled illustrative).
- SECURITY FIX (found by the new tests): reserved suffixes such as .localdomain, .intranet, .private, .test, .invalid, .example and .arpa are rejected. A connection-time guard (lib/safeHttp.js) now re-resolves every host and refuses private/internal answers (DNS rebinding) and aborts redirects to private IP literals. Before this, only the first lookup at scan start was checked and redirects were followed unchecked.
- Tests: 42 pass. See TEST-REPORT.md for what was and was not run.

## Still NOT done
- Engine registry / common adapter interface for the 12 engine families; finding IDs and the VERIFIED / PARTIALLY VERIFIED / CONTRADICTED vocabulary; DOCX watermark and graph image; coloured severity badges and tables in PDF/DOCX; IP lookups saved to My Reports; legal (Terms/Privacy) links in the homepage footer (no such pages exist in the project); persistent-storage guidance for free hosting; stored automated browser tests.

## Seventh pass
- Findings now carry an id (F-001...) and a verification label: VERIFIED (observed directly, High confidence), PARTIALLY VERIFIED (observed directly, lower confidence), UNVERIFIED (third-party or heuristic data). This label is DERIVED from the existing `verified` flag and confidence; CONTRADICTED and per-source disagreement tracking are NOT implemented. The label is shown in PDF/DOCX/Executive Summary.
- lib/engineRegistry.js: the 12 engine families mapped to the real collectors, with status derived from each report's evidence (ok / partial / failed / no data / not run / built-in). Shown in "Investigation Methodology" and at GET /api/engine-registry. This is a status mapping, not a new runtime plug-in system; the older collectors still have no common adapter interface.
- Homepage footer shows Terms/Privacy only if TERMS_URL / PRIVACY_URL are set (no legal text was written).
- DEPLOY.md (persistence warning for free hosting, env, limits). tests/browser/smoke.js: optional stored Playwright smoke test (needs playwright installed). 43/43 automated tests pass.

## Still NOT done
- Common adapter interface for the old collectors; CONTRADICTED / source-disagreement tracking; DOCX watermark and graph image; coloured severity badges and tables in PDF/DOCX; IP lookups saved to My Reports; Terms/Privacy pages themselves; real-tool, live-source and better-sqlite3 verification; the original My Reports complaint (not reproduced).

## Eighth pass
- lib/disagreements.js: WHOIS vs RDAP registrar and expiry comparison. When they differ, both values are kept and labelled CONTRADICTED in the Coverage section, the Investigation Summary count and the Workspace Domain tab. Missing/failed sides never create a disagreement. Verified with unit tests and a synthetic conflicting report; NOT verified on a real domain.
- AUDIT.md: audit checklist, source availability matrix, delivery summary (prompt sections 2.1, 13, 19).

## Ninth pass
- PDF and DOCX: HIGH / MEDIUM / LOW findings get a coloured marker (PDF side bar, DOCX coloured bold tag). Checked visually in the PDF; DOCX colour NOT visually checked.
- Dashboard: findings by severity (fresh scans only, so cached repeats are not double counted) and "Completed with gaps" (scans where at least one collector did not return data). Backed by additive columns on `scans`; scans recorded before this update count as 0 for these.
- Help & documentation view in the app (verification labels, PARTIAL, modules, limits).
- Workspace: graph PNG download (valid 1600x1120 PNG), per-dork explanation derived from the operators in the query, saved dork filters (browser localStorage, 20 max), download buttons locked while an export runs (no duplicate requests), clear messages for 401/404/410/413/429.
- BUG FIXED: the "Download SVG" button wrote an invalid SVG (duplicate xmlns). It now downloads valid XML (checked by parsing the downloaded file).
- 47 automated tests pass.

## Still NOT done
- DOCX watermark and graph image; per-module PDF/DOCX reports; IP lookups saved to My Reports; A-P section order; common adapter interface for the older collectors; freshness / last-seen / UNAVAILABLE fields per finding; running/pending scan counts (scans are synchronous); central design system for the whole app; Terms/Privacy pages; DB transaction and concurrency audit.
- Not verified: the original My Reports complaint, live sources, real external tools, better-sqlite3, the real logo, production cookie flags, load limits, DOCX page appearance.

## Tenth pass
- Report order now follows the prompt's A-P order (Executive Summary, Methodology, Domain, IP/ASN, Subdomain, Email, Company, Social, Historical, Search, Google Dorking, Website metadata, Media, Professional footprint, Threat, Graph, Findings & Recommendations, Evidence, Coverage, Investigation Summary), numbered automatically. Added a "Google Dorking" section (query list, links only). "Recommended Actions" is now "Findings & Recommendations". Verified in the exported PDF.
- Module extracts: Workspace "Word (this module)" / "PDF (this module)" export only that module's section plus Coverage & Limitations; file name ends in -module. Verified downloads.
- IP lookups are saved to My Reports (kind "ip"), open as an IP result, and are excluded from domain-only views (Workspace latest report, dashboard module coverage).
- CORRECTION: the earlier note "IP lookups are counted on the Dashboard" was WRONG. They never were: the scan log was given the rate-limit key ("u" + id) instead of the numeric user id, so every insert failed silently with a FOREIGN KEY error. Fixed and covered by a regression test.
- 48 automated tests pass.

## Eleventh pass (new master prompt)
- PDF: Table of Contents (page numbers verified against the real pages), tagline "Everything Digital One Destination" on the cover and every footer (DOCX footer too; BRAND_TAGLINE overrides), Investigation ID on the cover.
- Six-status classification (VERIFIED, UNVERIFIED, NOT FOUND, FAILED, PARTIAL, SOURCE UNAVAILABLE) on every evidence row; shown in Methodology, Workspace and Help. Derived rule documented in lib/classification.js: only our own direct checks (DNS, TLS/headers, email DNS) can be VERIFIED; failed or empty modules never are.
- PHASE1-AUDIT.md: honest requirement-by-requirement status for the new prompt, including what is NOT done (guest mode, live progress/cancel, job queue, evidence/audit tables, Source Manager, theme toggle, Settings page, isolated worker).
- Bug caught during this pass: the classification step was first placed before evidence existed, so it never ran; found because the result was checked in the real PDF.
- 50 automated tests pass.
- Follow-up fixes found by checking the offline (no-mock) scan: when crt.sh, OTX and Anubis are ALL unreachable the Subdomains collector now fails (-> SOURCE UNAVAILABLE) instead of returning an empty list that read as NOT FOUND; IP & ASN, Ports & CVEs and Exploited CVEs report "not run: no IP address was resolved" (-> FAILED) when no IP was resolved. NOT FOUND now only means a source answered with nothing. 51 tests pass.

## Twelfth pass: guest mode
- Guests (no account) can open /scan, run domain scans and IP lookups, use the Scan Workspace on their current result, see a session-only dashboard, and export the current result (PDF/DOCX/JSON). Every other route still requires login: reports, saved investigations, dashboard analytics, account, settings, engines (guest.test.js checks 401 on each).
- Safety: same consent, SSRF, redirect and rebinding rules as accounts. Quota per client IP (hashed with a salt): default 2 scans per window, never above RATE_LIMIT; IP lookups share it; cached reports cost nothing. Server-wide cap on simultaneous guest scans (GUEST_MAX_CONCURRENT=3) and 10 guest exports per hour per IP. Env switches: ALLOW_GUEST, GUEST_RATE_LIMIT, GUEST_MAX_CONCURRENT, GUEST_EXPORT.
- Retention policy: a guest's results are kept only in the browser tab (sessionStorage, last 5 scans). Nothing is written to reports or scans tables. The server still keeps the hashed-IP quota counter and the existing 24 h public-data cache of a scanned domain (not tied to the guest); the UI says so.
- The old test that expected 401 for logged-out export now expects the guest policy (200); GUEST_EXPORT=0 restores 401/403 behaviour.
- Bug caught while patching: a blanket replace turned the quota helper into a self-calling function (infinite recursion); noticed from a count printed by the patch script and fixed before any run. 56 automated tests pass.
- Known limits: IP-based quotas can be bypassed by an attacker who rotates IPs; concurrency/export counters are in memory and reset on restart; behind a proxy TRUST_PROXY=1 is required or all guests share one quota.

## Thirteenth pass: cancel, re-run, progress
- Scan Center: live status line (elapsed time, collectors finished, collectors failed); "Cancel scan"; "Try again" after a cancel or error; "Re-run scan (fresh data)" on reports with failed or empty modules (ignores the 24 h cache, needs the confirmation box ticked again, uses one scan from the limit). API: `refresh: true` on /api/recon and /api/recon/stream.
- Cancel semantics (be aware): the server treats a closed connection as cancelled. The result is discarded, nothing is saved, the quota is NOT refunded (otherwise start+cancel would bypass the limit while the collectors keep running for up to ~60 s), and the dashboard counts it as Cancelled. BEHAVIOUR CHANGE: closing the tab or a network drop mid-scan used to still finish and save the report; now it counts as cancelled. Set CANCEL_ON_DISCONNECT=0 to restore the old behaviour.
- Dashboard shows Cancelled. Tests: cancel.test.js (a real client disconnect on a slow mock) and refresh test. 58 automated tests pass.
- Correction: the app already had a saved light/dark toggle; PHASE1-AUDIT.md wrongly said it did not.
- Still not done: background jobs surviving a closed tab or restart, retrying only the failed collectors, estimated time remaining.

## Fourteenth pass: execution timeline, collector runs, audit log, dashboard analytics
- Every scan now records its real execution: investigation start, each collector's start, finish or failure (duration, attempts, error text), a classification event and the finish. It is stored inside the report (`execution`), shown as the report section "Investigation Timeline" (right after Methodology, in PDF/DOCX/JSON) and in Scan Workspace > Reports. Older and cached reports show the original timeline or a "predates this feature" note.
- New additive tables: `collector_runs` (one row per collector run, per user) and `audit_log`. Audit entries: scan completed (incl. cached), failed, cancelled, export, IP lookup, report deleted, sign-in/register/logout outcomes (status code only; no email, password or report content). Guest actions are logged without a user. Entries older than AUDIT_RETENTION_DAYS (default 90) are deleted at startup. `GET /api/audit` returns only your own entries.
- Dashboard: module usage and source status (from stored runs, so they only reflect scans made after this update), recent failed tasks, activity log, quick actions. Guests get a note instead of analytics but can use the quick actions.
- BUG caught by the checks: my new quick-action buttons made the dashboard overflow by 348 px at 320 px wide. Fixed (button rows wrap); all seven widths re-measured at 0 px.
- 59 automated tests pass.
- Not done: verified-findings card, recent findings/reports lists, per-finding evidence table and verification timestamps, source-request-level events.

## Fifteenth pass: finding evidence, source health, settings
- Every finding now carries an evidence record: ID, verification label, method (direct check vs third-party/heuristic), collected time, the time the label was applied, limitation text and related finding IDs (same source). These are DERIVED from how the finding was collected; the label time is not an independent verification. Shown in Scan Workspace > Reports (search by ID, text or source; filter by severity and verification; sort; 10 per page; expandable evidence) and as the report section "Finding Evidence Appendix" (PDF/DOCX/JSON).
- Dashboard: Verified findings card (fresh scans only), Latest findings (top findings of your latest saved domain report), Recent reports with Open, Source health. GET /api/sources aggregates collector health over all signed-in scans and returns only collector names, times, counts and an error class (never targets or raw errors; tested). There is NO circuit breaker: a failing source is still tried on every scan.
- Settings page (theme: system/light/dark, default dashboard range, clear saved dork filters). Stored in the browser only; hidden for guests.
- Test notes: one new test first failed because the test user's own scan quota was used up by earlier tests (not a code bug); fixed by using a fresh user. A browser check "every CVE search hit mentions CVE in its title" printed False; investigation showed the search deliberately covers ID, text and source, and every hit matches in title or source. The search box now says "Search ID, text or source". 60 automated tests pass.
- Still not done: circuit breaker/throttling, background jobs, queue and isolated worker, a separate evidence/investigations/jobs table, verification timestamps from an independent step, retry of only the failed collectors, DNSRecon/Sherlock/ExifTool, DOCX watermark and table of contents, central design system, Terms/Privacy pages.

## Sixteenth pass: circuit breaker, stored findings, grouped Scan Center menu
- Circuit breaker (lib/breaker.js): third-party sources (WHOIS, RDAP, Subdomains, Wayback, IP & ASN, Archived URLs, CISA KEV, Threat feeds), the SoftInza engine's four sources and external tools are skipped after BREAKER_FAILURES (3) consecutive reachability failures, for BREAKER_COOLDOWN_SEC (300, minimum 5), then one trial run is allowed; a failed trial re-opens it at once. Only connection/timeout/429/5xx/blocked-type errors count (a 404 or parse error on one domain does not), and target-facing collectors (website, TLS, headers, SPF/DMARC, security.txt, lookalikes) are never guarded. A skipped source appears in the timeline as `collector_skipped`, in the report as failed / SOURCE UNAVAILABLE ("circuit open ... retry in Ns"), is not counted as a run, and shows as "circuit open" in Source health. State is in memory and resets on restart. The offline test mock disables it by default (it fails WHOIS on every scan on purpose).
- Tables `investigations` (one row per fresh scan) and `findings_log` (one row per finding, per user, deleted with the account). GET /api/findings (own findings, filters sev, ver, q; limit/offset). The dashboard's Latest findings now come from this table (newest scan first, then severity). Findings of reports deleted from My Reports stay in findings_log until the account is deleted.
- DOCX gets a "Contents" list of the section titles. It has NO page numbers (Word's layout engine is needed for those) and no watermark.
- Sidebar: Scan Center is a grouped, expandable list of the 10 categories. BUG found by a touch test on a 320 px device: tapping the group closed the mobile drawer, hiding the list it had just opened (the generic nav handler treated the group as a page link). Fixed (the group only expands; picking an item navigates), and the stored smoke test now asserts the drawer stays open and the items are on screen. Clicking the group on desktop no longer jumps to the workspace by itself.
- 64 automated tests pass.

## Seventeenth pass: background jobs (API and UI)
- Signed-in users can queue scans that run on the server without the browser: POST /api/jobs {domain, consent, refresh}, GET /api/jobs, GET /api/jobs/:id (status, queue position, collectors finished/failed, current step, report id), POST /api/jobs/:id/cancel. Table `jobs`; in-process FIFO queue with JOB_CONCURRENCY workers (default 2), JOB_QUEUE_MAX (20) and JOB_MAX_ACTIVE per user (3).
- Same rules as normal scans: consent required, name checked BEFORE queuing (a bad name costs no quota), SSRF guard, quota spent when queued, report saved as usual with the same timeline, findings and audit entries. Quota: refunded if the job is cancelled while still waiting or if it fails; NOT refunded if cancelled while running (the work started) and not for interrupted jobs.
- A server restart cannot resume work: waiting and running jobs become "interrupted" (tested with a real kill and restart). Finished jobs are kept 30 days.
- UI: a "Run in the background" checkbox on the Scan page (signed-in users only; hidden for guests) starts a job and shows queue position, collectors finished/failed, elapsed time and Cancel; a "Background scans" card on the Dashboard lists recent jobs with Open and Cancel and refreshes itself while a job is active. Without the checkbox the scan still runs as the live streaming scan, where closing the tab cancels it (CANCEL_ON_DISCONNECT).
- Verified in a real browser (one scripted run on the slow mock): a scan was started, the tab was closed mid-scan, and after returning the report was in My Reports and the job showed as completed with an Open button; cancelling from the scan page worked.
- NOT done: worker health monitoring, an isolated worker process (jobs run inside the web server process), resuming jobs after a restart.
- 68 automated tests pass.
